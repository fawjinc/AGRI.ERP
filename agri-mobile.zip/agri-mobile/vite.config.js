import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// base: './' يضمن أن مسارات الملفات نسبية — مطلوب غالباً لتطبيقات Capacitor
export default defineConfig({
  plugins: [react()],
  base: './'
});
