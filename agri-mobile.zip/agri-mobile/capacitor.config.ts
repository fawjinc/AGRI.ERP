import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.agri.erp',
  appName: 'أجري ERP',
  webDir: 'dist',
  server: {
    // androidScheme: 'https' يجعل WebView يقدّم الملفات عبر https://localhost
    // بدلاً من file://، وهو المطلوب لتعمل localStorage وبعض الخصائص بشكل سليم.
    androidScheme: 'https'
  }
};

export default config;
