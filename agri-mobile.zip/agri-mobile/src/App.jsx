import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  Home,
  Compass,
  Trees,
  Settings,
  Plus,
  CheckCircle2,
  AlertTriangle,
  Globe,
  TrendingUp,
  TrendingDown,
  ArrowUpRight,
  ArrowDownRight,
  ChevronLeft,
  ChevronRight,
  Trash2,
  X,
  Check,
  Sparkles,
  Download,
  Upload,
  RotateCcw,
  Wallet,
  Package,
  Sliders,
  Info,
  Moon,
  Sun,
  Pencil
} from 'lucide-react';

// ==========================================
// الهيكل: مزارع ← مزرعة ← وحدات (رشاش / بيت محمي / بستان)
// كل وحدة لها طريقة حساب خاصة بها:
//  - الرشاش المحوري: بالهكتار (أبراج × زاوية دوران)
//  - البيت المحمي: بالشتلة (صالات ← خطوط ← شتلات/خط)
//  - البستان: بالشجرة (أصناف ← عدد أشجار)
// ==========================================

const todayISO = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};

const daysUntil = (iso) => {
  if (!iso) return null;
  const [y, m, d] = iso.split('-').map(Number);
  const target = new Date(y, m - 1, d);
  const now = new Date();
  const start = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  return Math.round((target - start) / 86400000);
};

const formatCurrency = (val, lang = 'ar') => {
  const num = Math.round(Number(val) || 0);
  return lang === 'ar' ? `${num.toLocaleString('ar-SA')} ر.س` : `SAR ${num.toLocaleString('en-US')}`;
};
const formatNumber = (val, lang = 'ar', digits = 0) => {
  const num = Number(val) || 0;
  return num.toLocaleString(lang === 'ar' ? 'ar-SA' : 'en-US', { minimumFractionDigits: digits, maximumFractionDigits: digits });
};

const sumAmount = (list) => list.reduce((s, t) => s + (Number(t.amount) || 0), 0);
const isReceivable = (t) => t.type === 'revenue' && t.status === 'مستحق للتحصيل';
const isPayable = (t) => t.type === 'expense' && String(t.status).startsWith('ذمم');

// طول البرج ثابت 50 م
// نصف القطر = (أبراج × 50) + طول التوصيلة (لو موجودة فعلاً - اختيارية تماماً)
// المساحة بالهكتار = π × r² × (الزاوية/360) ÷ 10000 — مقرّبة لرقمين
const TOWER_LENGTH = 50;
const calculatePivotArea = (towersCount, overhangLength, rotationAngle) => {
  const radius = towersCount * TOWER_LENGTH + (overhangLength || 0);
  const angle = rotationAngle || 360;
  return parseFloat(((Math.PI * radius * radius * (angle / 360)) / 10000).toFixed(2));
};
const calcPivotGeometry = (p) => {
  const towers = Math.max(0, Number(p.towers) || 0);
  const ext = p.hasExtension ? Number(p.extensionLength) || 0 : 0;
  const angle = Math.min(360, Math.max(1, Number(p.operatingAngle) || 360));
  const radius = towers * TOWER_LENGTH + ext;
  return { radius, diameter: radius * 2, fullHa: (Math.PI * radius * radius) / 10000, sectorHa: calculatePivotArea(towers, ext, angle) };
};

const GEOMETRY_KEYS = ['towers', 'spanLength', 'hasExtension', 'extensionLength', 'operatingAngle'];

const CATEGORY_DEFAULTS = {
  grains: { baleWeightKg: 50, rollWeightKg: 1000, marketPricePerUnit: 1850 },
  forage: { baleWeightKg: 25, rollWeightKg: 350, marketPricePerUnit: 24 },
  tubers: { baleWeightKg: 25, rollWeightKg: 1000, marketPricePerUnit: 1450 }
};

// تكلفة وحدة الإنتاج للرشاش: الإنتاج (طن) = عدد الأكياس/اللبنات × الوزن ÷ 1000
const calcTonsFromBags = (bagsCount, bagWeightKg) => +(((Number(bagsCount) || 0) * (Number(bagWeightKg) || 0)) / 1000).toFixed(2);
// الحبوب والدرنيات: السعر للطن — الأعلاف: السعر للّبنة
const calcUnitCost = ({ expenses, tons, bagWeightKg, price, priceUnit }) => {
  if (!(tons > 0)) return null;
  const units = bagWeightKg > 0 ? (tons * 1000) / bagWeightKg : 0;
  const revenue = priceUnit === 'ton' ? tons * price : units * price;
  return { costPerTon: expenses / tons, costPerUnit: units ? expenses / units : 0, revenue, profit: revenue - expenses };
};
// الإنتاج الفعلي: يتبع المحسوب من الأكياس تلقائياً، إلا لو كتبه المستخدم يدوياً
const pivotProductionTons = (p) =>
  p.productionMode !== 'manual' && Number(p.bagsCount) > 0 ? calcTonsFromBags(p.bagsCount, p.baleWeightKg) : Number(p.productionTons) || 0;

const EXPENSE_CATEGORIES = [
  { key: 'أسمدة', en: 'Fertilizers', color: 'bg-emerald-600' },
  { key: 'كهرباء ووقود', en: 'Fuel & power', color: 'bg-amber-500' },
  { key: 'بذور وشتلات', en: 'Seeds & seedlings', color: 'bg-teal-600' },
  { key: 'صيانة', en: 'Maintenance', color: 'bg-rose-600' },
  { key: 'عمالة', en: 'Labor', color: 'bg-sky-600' },
  { key: 'مبيدات', en: 'Pesticides', color: 'bg-purple-600' }
];

const buildCategoryBreakdown = (txs) => {
  const expenseTxs = txs.filter((t) => t.type === 'expense');
  const total = sumAmount(expenseTxs);
  return EXPENSE_CATEGORIES.map((cat) => {
    const items = expenseTxs.filter((t) => t.category === cat.key);
    const amount = sumAmount(items);
    return { ...cat, amount, count: items.length, pct: total > 0 ? Math.round((amount / total) * 100) : 0 };
  }).filter((c) => c.amount > 0);
};

// عدد شتلات البيت المحمي = مجموع (عدد خطوط الصالة × شتلات الخط) لكل الصالات
const greenhousePlantCount = (gh) => (gh.halls || []).reduce((s, h) => s + (Number(h.rows) || 0) * (Number(h.plantsPerRow) || 0), 0);
// عدد أشجار البستان = مجموع عدد أشجار كل الأصناف
const orchardTreeCount = (orc) => (orc.varieties || []).reduce((s, v) => s + (Number(v.treeCount) || 0), 0);

const buildUnitFinance = (unitType, unitId, transactions) => {
  const txList = transactions.filter((t) => t.unitType === unitType && t.unitId === unitId);
  const expenses = sumAmount(txList.filter((t) => t.type === 'expense'));
  const revenues = sumAmount(txList.filter((t) => t.type === 'revenue'));
  return { txList, expenses, revenues, netProfit: revenues - expenses, byCategory: buildCategoryBreakdown(txList) };
};

const STORAGE_KEY = 'agri-erp-state';
const STORAGE_VERSION = 3;

// رابط Google Apps Script الذي يستقبل بيانات العملاء ويكتبها في Google Sheet
const LEADS_URL = import.meta.env.VITE_LEADS_URL || 'https://script.google.com/macros/s/AKfycbw2854SG-hWzkQ6PhNLBdAashJEukdT4cvD6CW8TcSA2aEj7wgn2EKQgIc3I-7YFaTjjw/exec';
const LEAD_PENDING_KEY = 'agri-lead-pending';

const normalizePhone = (v) => String(v || '').replace(/[\s-]/g, '').replace(/^\+?966/, '0').replace(/^5/, '05');
const isValidPhone = (v) => /^05\d{8}$/.test(normalizePhone(v));

const postLead = async (lead) => {
  if (!LEADS_URL) return false;
  try {
    await fetch(LEADS_URL, { method: 'POST', mode: 'no-cors', headers: { 'Content-Type': 'text/plain;charset=utf-8' }, body: JSON.stringify(lead) });
    return true;
  } catch {
    return false;
  }
};

// يرسل بيانات العميل، وإذا لم يوجد إنترنت يحفظها ويعيد المحاولة عند الفتح التالي
const sendLead = async (lead) => {
  const ok = await postLead(lead);
  try {
    if (ok) window.localStorage.removeItem(LEAD_PENDING_KEY);
    else window.localStorage.setItem(LEAD_PENDING_KEY, JSON.stringify(lead));
  } catch {}
};

// ملخص المزرعة: يُرسل فقط عند تغيّر الأرقام، وبعد 15 ثانية من آخر تعديل
const SUMMARY_SENT_KEY = 'agri-summary-sent';
const sendSummaryIfChanged = (summary) => {
  const sig = JSON.stringify(summary);
  try {
    if (window.localStorage.getItem(SUMMARY_SENT_KEY) === sig) return;
  } catch {}
  postLead({ kind: 'summary', ...summary }).then((ok) => {
    if (ok) {
      try { window.localStorage.setItem(SUMMARY_SENT_KEY, sig); } catch {}
    }
  });
};

const retryPendingLead = () => {
  try {
    const raw = window.localStorage.getItem(LEAD_PENDING_KEY);
    if (raw) sendLead(JSON.parse(raw));
  } catch {}
};

const loadSavedState = () => {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const data = JSON.parse(raw);
    return data && data.version === STORAGE_VERSION ? data : null;
  } catch {
    return null;
  }
};

// ==========================================
// بيانات تجريبية
// ==========================================

const INITIAL_FARMS = [{ id: 'farm-1', name: 'مزرعة القصيم النموذجية', location: 'القصيم - بريدة' }];

const INITIAL_PIVOTS = [
  {
    id: 'piv-1',
    farmId: 'farm-1',
    name: 'رشاش 1 - الشمالي (قمح)',
    towers: 8,
    spanLength: TOWER_LENGTH,
    hasExtension: true,
    extensionLength: 18.5,
    operatingAngle: 360,
    actualMeasuredArea: 65.4,
    areaMode: 'manual',
    currentCrop: 'قمح - يوكورا روجو',
    cropCategory: 'grains',
    productionTons: 480,
    baleWeightKg: 50,
    rollWeightKg: 1000,
    marketPricePerUnit: 1850,
    status: 'يعمل حالياً'
  },
  {
    id: 'piv-2',
    farmId: 'farm-1',
    name: 'رشاش 2 - الجنوبي (برسيم)',
    towers: 6,
    spanLength: TOWER_LENGTH,
    hasExtension: false,
    extensionLength: 0,
    operatingAngle: 270,
    actualMeasuredArea: 25.5,
    areaMode: 'manual',
    currentCrop: 'برسيم حجازي (أعلاف)',
    cropCategory: 'forage',
    productionTons: 225,
    baleWeightKg: 25,
    rollWeightKg: 350,
    marketPricePerUnit: 24,
    status: 'يعمل حالياً'
  }
];

const INITIAL_GREENHOUSES = [
  {
    id: 'gh-1',
    farmId: 'farm-1',
    name: 'مجمع الطماطم المبرد',
    crop: 'طماطم شيري وعنقودية',
    variety: 'إيزابيلا F1',
    plantingDate: '2026-09-01',
    halls: [
      { id: 'hall-1', name: 'صالة 1', rows: 20, rowLength: 100, plantsPerRow: 40 },
      { id: 'hall-2', name: 'صالة 2', rows: 20, rowLength: 100, plantsPerRow: 40 }
    ],
    productionTons: 68.5,
    boxWeightKg: 5,
    sellingPricePerBox: 18
  }
];

const INITIAL_ORCHARDS = [
  {
    id: 'orc-1',
    farmId: 'farm-1',
    name: 'بستان النخيل والحمضيات',
    varieties: [
      { id: 'var-1', treeType: 'نخيل التمر', variety: 'سكري القصيم', treeCount: 9200, treeAge: 9 },
      { id: 'var-2', treeType: 'حمضيات', variety: 'أبو صرة', treeCount: 5500, treeAge: 5 }
    ],
    productionTons: 815,
    boxWeightKg: 5,
    sellingPricePerBox: 22
  }
];

const INITIAL_TRANSACTIONS = [
  { id: 'trx-1', type: 'revenue', category: 'مبيعات المحاصيل', title: 'دفعة مبيعات قمح', farmId: 'farm-1', unitType: 'pivot', unitId: 'piv-1', date: '2026-11-03', amount: 345000, quantityLabel: '230 طن متوقع', invoiceNo: 'INV-PV1-01', paymentMethod: 'تحويل بنكي', status: 'محصل', notes: '' },
  { id: 'trx-2', type: 'expense', category: 'أسمدة', title: 'يوريا 46% + داب', farmId: 'farm-1', unitType: 'pivot', unitId: 'piv-1', date: '2026-11-01', amount: 24900, quantityLabel: '220 كيس', invoiceNo: 'EXP-PV1-104', paymentMethod: 'تحويل بنكي', status: 'مدفوع', notes: '' },
  { id: 'trx-3', type: 'expense', category: 'كهرباء ووقود', title: 'ديزل مضخة الرشاش 1', farmId: 'farm-1', unitType: 'pivot', unitId: 'piv-1', date: '2026-10-29', amount: 14850, quantityLabel: '8,500 لتر', invoiceNo: 'EXP-PV1-108', paymentMethod: 'تحويل بنكي', status: 'مدفوع', notes: '' },
  { id: 'trx-4', type: 'revenue', category: 'مبيعات المحاصيل', title: 'بيع بالات برسيم', farmId: 'farm-1', unitType: 'pivot', unitId: 'piv-2', date: '2026-10-28', amount: 162000, quantityLabel: '4,500 بالة', invoiceNo: 'INV-PV2-04', paymentMethod: 'نقدي / شبكة', status: 'محصل', notes: '' },
  { id: 'trx-5', type: 'expense', category: 'كهرباء ووقود', title: 'ديزل مضخة الرشاش 2', farmId: 'farm-1', unitType: 'pivot', unitId: 'piv-2', date: '2026-10-20', amount: 16400, quantityLabel: '9,200 لتر', invoiceNo: 'EXP-PV2-18', paymentMethod: 'تحويل بنكي', status: 'مدفوع', notes: '' },
  { id: 'trx-6', type: 'expense', category: 'أسمدة', title: 'سمدة NPK + كالسيوم بورون (دفعة أولى)', farmId: 'farm-1', unitType: 'greenhouse', unitId: 'gh-1', date: '2026-09-20', amount: 31000, quantityLabel: '620 كجم (دفعة)', invoiceNo: 'EXP-GH1-04', paymentMethod: 'تحويل بنكي', status: 'مدفوع', notes: '' },
  { id: 'trx-7', type: 'expense', category: 'كهرباء ووقود', title: 'كهرباء التبريد والمراوح', farmId: 'farm-1', unitType: 'greenhouse', unitId: 'gh-1', date: '2026-10-31', amount: 38000, quantityLabel: 'سبتمبر + أكتوبر', invoiceNo: 'EXP-GH1-09', paymentMethod: 'تحويل بنكي', status: 'مدفوع', notes: '' },
  { id: 'trx-8', type: 'expense', category: 'بذور وشتلات', title: '1,600 شتلة طماطم مطعمة', farmId: 'farm-1', unitType: 'greenhouse', unitId: 'gh-1', date: '2026-08-28', amount: 26000, quantityLabel: '1,600 شتلة', invoiceNo: 'EXP-GH1-01', paymentMethod: 'تحويل بنكي', status: 'مدفوع', notes: '' },
  { id: 'trx-9', type: 'expense', category: 'أسمدة', title: 'سماد بوتاسيوم للنخيل (محببات/شجرة)', farmId: 'farm-1', unitType: 'orchard', unitId: 'orc-1', date: '2026-10-05', amount: 42000, quantityLabel: '2.1 طن', invoiceNo: 'EXP-ORC-05', paymentMethod: 'تحويل بنكي', status: 'مدفوع', notes: '' },
  { id: 'trx-10', type: 'revenue', category: 'مبيعات المحاصيل', title: 'بيع تمور وحمضيات (فلينة)', farmId: 'farm-1', unitType: 'orchard', unitId: 'orc-1', date: '2026-11-02', amount: 485000, quantityLabel: '32 طن', invoiceNo: 'INV-ORC-01', paymentMethod: 'تحويل بنكي', status: 'محصل', notes: '' },
  { id: 'trx-11', type: 'expense', category: 'عمالة', title: 'أجور قطاف وتربيط', farmId: 'farm-1', unitType: 'orchard', unitId: 'orc-1', date: '2026-10-31', amount: 28000, quantityLabel: 'شهر أكتوبر', invoiceNo: 'EXP-ORC-09', paymentMethod: 'آجل (ذمم)', status: 'ذمم دائنة', notes: '' }
];

// معرّفات البيانات التجريبية لتمييزها عن بيانات العميل
const DEMO_IDS = new Set(
  [...INITIAL_FARMS, ...INITIAL_PIVOTS, ...INITIAL_GREENHOUSES, ...INITIAL_ORCHARDS, ...INITIAL_TRANSACTIONS].map((x) => x.id)
);
const isDemo = (x) => DEMO_IDS.has(x.id);

const DEFAULT_PROFILE = {
  name: 'م. عبدالله القصيمي',
  phone: '0504829100',
  city: 'القصيم - بريدة',
  enabledTypes: ['pivots', 'greenhouses', 'orchards']
};

const UNIT_TYPES = [
  { id: 'pivots', key: 'pivot', label: 'الرشاشات المحورية', labelEn: 'Center pivots', icon: Compass, color: 'emerald' },
  { id: 'greenhouses', key: 'greenhouse', label: 'البيوت المحمية', labelEn: 'Greenhouses', icon: Home, color: 'sky' },
  { id: 'orchards', key: 'orchard', label: 'البساتين والنخيل', labelEn: 'Orchards', icon: Trees, color: 'amber' }
];

// ==========================================
// رسم الرشاش المتحرك: الذراع تلف دورة كاملة للدائرة، وذهاب وعودة داخل القطاع للزاوية الجزئية
// ==========================================
const PIVOT_REDUCE_MOTION = typeof window !== 'undefined' && window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

const renderPivotSvg = (s, phase, gid) => {
  const C = 100, R = 80, a = Math.min(360, Math.max(1, s.angle || 360));
  const pt = (r, d) => [C + r * Math.cos(((d - 90) * Math.PI) / 180), C + r * Math.sin(((d - 90) * Math.PI) / 180)];
  const sector = (r) => {
    if (a >= 360) return `<circle cx="${C}" cy="${C}" r="${r}"`;
    const [x, y] = pt(r, a);
    return `<path d="M${C},${C}L${C},${C - r}A${r},${r} 0 ${a > 180 ? 1 : 0},1 ${x},${y}Z"`;
  };
  const armDeg = a >= 360 ? (phase * 360) % 360 : Math.abs(((phase * 2) % 2) - 1) * a;
  const ohR = s.hasOverhang && s.radius > 0 ? (R * (s.towers * TOWER_LENGTH)) / s.radius : R;
  // الجزء المروي (أثر الذراع)
  let wet = '';
  if (a >= 360 && armDeg > 1) {
    const [x, y] = pt(R, armDeg);
    const [x0, y0] = pt(R, 0);
    wet = `<path d="M${C},${C}L${x0},${y0}A${R},${R} 0 ${Math.min(armDeg, 359.9) > 180 ? 1 : 0},1 ${x},${y}Z" fill="#2bd68a" fill-opacity=".18"/>`;
  }
  let towers = '';
  const n = Math.min(30, s.towers);
  for (let i = 1; i <= n; i++) {
    const [x, y] = pt((ohR * i) / n, armDeg);
    towers += `<circle cx="${x}" cy="${y}" r="3.2" fill="#3ee08f" stroke="#062a22" stroke-width="1"/>`;
  }
  const [ax, ay] = pt(R, armDeg);
  // رذاذ عند طرف الذراع
  let spray = '';
  if (!PIVOT_REDUCE_MOTION)
    for (let i = 0; i < 5; i++) {
      const j = (phase * 37 + i * 0.2) % 1;
      const [sx, sy] = pt(R + 4 + j * 8, armDeg + (i - 2) * 2.5);
      spray += `<circle cx="${sx}" cy="${sy}" r="${1.6 - j}" fill="#9fe8ff" fill-opacity="${1 - j}"/>`;
    }
  const ring = s.hasOverhang ? sector(R) + ` fill="none" stroke="#e6c229" stroke-width="2.5"/>` : '';
  const stroke = s.hasOverhang ? `stroke="#2bd68a" stroke-width="2.5" stroke-dasharray="3 3"` : `stroke="#2bd68a" stroke-width="2.5"`;
  return `<defs><radialGradient id="${gid}"><stop offset="0" stop-color="#11604f"/><stop offset="1" stop-color="#0b3f37"/></radialGradient></defs>
    ${ring}${sector(R)} fill="url(#${gid})" ${stroke}/>${wet}
    <line x1="${C}" y1="${C}" x2="${ax}" y2="${ay}" stroke="#fff" stroke-width="3" stroke-linecap="round"/>
    ${towers}${spray}<circle cx="${C}" cy="${C}" r="7" fill="#f39c12"/>`;
};

const PivotSvgVisualizer = ({ towers, hasExtension, extensionLength, angle }) => {
  const svgRef = useRef(null);
  const gid = useRef(`pg${Math.random().toString(36).slice(2, 8)}`).current;
  const t = Math.max(0, Math.round(Number(towers) || 0));
  const a = Math.min(360, Math.max(1, Number(angle) || 360));
  const oh = hasExtension ? Number(extensionLength) || 0 : 0;
  const stateRef = useRef(null);
  stateRef.current = { towers: t, angle: a, hasOverhang: !!hasExtension, radius: t * TOWER_LENGTH + oh };

  useEffect(() => {
    if (PIVOT_REDUCE_MOTION) {
      if (svgRef.current) svgRef.current.innerHTML = renderPivotSvg(stateRef.current, 0.22, gid);
      return undefined;
    }
    let raf;
    const start = performance.now();
    const loop = (now) => {
      const phase = 0.22 + (now - start) / 5000; // دورة كاملة كل 5 ثواني
      if (svgRef.current) svgRef.current.innerHTML = renderPivotSvg(stateRef.current, phase, gid);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [gid, PIVOT_REDUCE_MOTION ? `${t}|${a}|${hasExtension}|${oh}` : '']);

  return (
    <div className="rounded-2xl px-2.5 pt-4 pb-3.5 text-center" style={{ background: 'linear-gradient(180deg,#062a22,#0f1628)' }}>
      <svg ref={svgRef} viewBox="0 0 200 200" className="w-full h-auto block mx-auto" style={{ maxWidth: 260 }} aria-label="رسم الرشاش" />
      <p className="mt-2.5 font-bold text-[15px]" style={{ color: '#8ee6b9' }}>
        {a}° • {t} أبراج{hasExtension ? ' + توصيلة' : ''}
      </p>
    </div>
  );
};

// ==========================================
// نموذج الرشاش — مشترك بين الإضافة والتعديل
// ==========================================
const PIVOT_CATEGORIES = [
  { id: 'grains', ar: 'حبوب', en: 'Grains' },
  { id: 'forage', ar: 'أعلاف', en: 'Forage' },
  { id: 'tubers', ar: 'خضار', en: 'Vegetables' }
];

const PivotForm = ({ initial, mode, tr, onSubmit }) => {
  const [f, setF] = useState(() => ({
    name: initial?.name || '',
    currentCrop: initial?.currentCrop && initial.currentCrop !== '—' ? initial.currentCrop : '',
    cropCategory: initial?.cropCategory || 'grains',
    towers: initial?.towers ?? 7,
    operatingAngle: initial?.operatingAngle ?? 360,
    hasExtension: !!initial?.hasExtension,
    extensionLength: initial?.hasExtension ? initial.extensionLength : '',
    manual: initial?.areaMode === 'manual',
    area: initial?.actualMeasuredArea ?? ''
  }));
  const set = (patch) => setF((prev) => ({ ...prev, ...patch }));
  const g = calcPivotGeometry(f);
  const area = f.manual ? f.area : g.sectorHa;
  const diff = f.manual && Number(f.area || 0) !== g.sectorHa;

  const submit = (e) => {
    e.preventDefault();
    const towers = Math.max(1, Math.round(Number(f.towers) || 1));
    const operatingAngle = Math.min(360, Math.max(1, Number(f.operatingAngle) || 360));
    const ext = f.hasExtension ? Number(f.extensionLength) || 0 : 0;
    const calc = calculatePivotArea(towers, ext, operatingAngle);
    onSubmit({
      name: f.name.trim(),
      currentCrop: f.currentCrop.trim(),
      cropCategory: f.cropCategory,
      towers,
      spanLength: TOWER_LENGTH,
      operatingAngle,
      hasExtension: f.hasExtension,
      extensionLength: ext,
      actualMeasuredArea: f.manual ? Number(f.area) || calc : calc,
      areaMode: f.manual ? 'manual' : 'auto'
    });
  };

  const inputCls = 'w-full px-3 py-3 rounded-xl border border-slate-300 bg-white text-[17px]';
  const numCls = 'w-full px-3 py-3 rounded-xl border bg-white text-[17px] font-bold tabular-nums text-right';

  return (
    <form onSubmit={submit} className="space-y-4">
      <div className="space-y-4">
        <div>
          <label className="block text-base font-extrabold text-slate-900 mb-1.5">{tr('الاسم', 'Name')}</label>
          <input value={f.name} onChange={(e) => set({ name: e.target.value })} placeholder={tr('رشاش 3 - الشرقي', 'Pivot 3 - East')} className={inputCls} />
        </div>
        <div>
          <label className="block text-base font-extrabold text-slate-900 mb-1.5">{tr('المحصول', 'Crop')}</label>
          <input value={f.currentCrop} onChange={(e) => set({ currentCrop: e.target.value })} placeholder={tr('قمح', 'Wheat')} className={inputCls} />
        </div>
        <div>
          <label className="block text-base font-extrabold text-slate-900 mb-1.5">{tr('نوع الإنتاج', 'Production type')}</label>
          <select value={f.cropCategory} onChange={(e) => set({ cropCategory: e.target.value })} className={inputCls}>
            {PIVOT_CATEGORIES.map((c) => (
              <option key={c.id} value={c.id}>{tr(c.ar, c.en)}</option>
            ))}
          </select>
        </div>
      </div>

      <div className="bg-white rounded-[22px] p-4 border border-slate-200 space-y-4">
        <h4 className="text-xl font-extrabold text-slate-900">{tr('الهندسة والمساحة', 'Geometry & area')}</h4>
        <PivotSvgVisualizer towers={f.towers} hasExtension={f.hasExtension} extensionLength={f.extensionLength} angle={f.operatingAngle} />
        <div className="grid grid-cols-3 gap-2">
          <div className="min-w-0">
            <label className="block text-[13px] font-bold text-slate-500 mb-1.5">{tr('الأبراج', 'Towers')}</label>
            <input type="number" min="1" step="1" dir="ltr" value={f.towers} onChange={(e) => set({ towers: e.target.value })} className={`${numCls} border-slate-300`} />
          </div>
          <div className="min-w-0">
            <label className="block text-[13px] font-bold text-slate-500 mb-1.5">{tr('الزاوية °', 'Angle °')}</label>
            <input type="number" min="1" max="360" step="1" dir="ltr" value={f.operatingAngle} onChange={(e) => set({ operatingAngle: e.target.value })} className={`${numCls} border-slate-300`} />
          </div>
          <div className="min-w-0">
            <label className="block text-[13px] font-bold text-emerald-700 mb-1.5">{tr('المساحة المعتمدة', 'Area used')}</label>
            <input type="number" min="0" step="0.01" dir="ltr" value={area} onChange={(e) => set({ area: e.target.value, manual: true })} className={`${numCls} border-emerald-500`} />
          </div>
        </div>
        <label className="flex items-center gap-2.5 text-[15px] font-bold text-slate-900">
          <input type="checkbox" checked={f.hasExtension} onChange={(e) => set({ hasExtension: e.target.checked })} className="w-[22px] h-[22px] shrink-0" />
          {tr('لديه توصيلة ومدفع إضافي (اختياري)', 'Has extension/end-gun (optional)')}
        </label>
        {f.hasExtension && (
          <div>
            <label className="block text-[13px] font-bold text-slate-500 mb-1.5">{tr('طول التوصيلة (م)', 'Extension length (m)')}</label>
            <input type="number" min="0" step="0.1" dir="ltr" value={f.extensionLength} onChange={(e) => set({ extensionLength: e.target.value })} className={`${numCls} border-slate-300`} />
          </div>
        )}
        <div className="bg-slate-50 rounded-2xl p-3.5 space-y-2.5">
          <div className="flex items-center justify-between">
            <span className="text-slate-500">{tr('المحسوب هندسياً', 'Calculated')}</span>
            <strong className="text-[17px] tabular-nums">{g.sectorHa} {tr('هكتار', 'ha')}</strong>
          </div>
          <p className="text-[13px] text-slate-500">
            {diff ? tr('المساحة أعلاه مقاسة يدوياً ومحمية من الاستبدال التلقائي.', 'Area above is measured manually and locked from auto-replacement.') : tr('المساحة المعتمدة = المحسوبة.', 'Area used = calculated.')}
          </p>
          {diff && (
            <button type="button" onClick={() => set({ manual: false })} className="w-full py-2.5 rounded-xl bg-emerald-50 text-[#1a5632] border border-emerald-500 text-base font-extrabold">
              {tr('اعتماد المساحة المحسوبة', 'Use calculated area')}
            </button>
          )}
        </div>
      </div>

      <button type="submit" className="w-full py-4 rounded-2xl bg-[#1a5632] text-white text-lg font-extrabold">
        {mode === 'edit' ? tr('حفظ التعديلات', 'Save changes') : tr('حفظ الرشاش', 'Save pivot')}
      </button>
    </form>
  );
};

// ==========================================
// حاسبة سمادة (جرام/وحدة × عدد الوحدات) — تُستخدم في البيت المحمي والبستان
// ==========================================
const FertilizerHelper = ({ unitLabel, unitCount, onApply, tr, num }) => {
  const [gramsPerUnit, setGramsPerUnit] = useState('');
  const [bagWeightKg, setBagWeightKg] = useState(50);
  const [bagPrice, setBagPrice] = useState('');
  const totalKg = unitCount > 0 && gramsPerUnit ? (Number(gramsPerUnit) * unitCount) / 1000 : 0;
  const bagsNeeded = bagWeightKg > 0 ? totalKg / bagWeightKg : 0;
  const amount = bagsNeeded * (Number(bagPrice) || 0);

  return (
    <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 space-y-2.5">
      <p className="text-xs font-extrabold text-emerald-950 flex items-center gap-1.5">
        <Sliders className="w-3.5 h-3.5" />
        {tr('حاسبة السمدة (اختياري)', 'Fertilizer batch helper (optional)')}
      </p>
      <p className="text-[11px] text-emerald-800">
        {tr(`عدد ${unitLabel}: `, `${unitLabel} count: `)}
        <strong>{num(unitCount)}</strong>
      </p>
      <div className="grid grid-cols-3 gap-2">
        <div>
          <label className="text-[10px] font-bold text-slate-600 block mb-0.5">{tr(`جرام/${unitLabel}`, `g/${unitLabel}`)}</label>
          <input type="number" min="0" value={gramsPerUnit} onChange={(e) => setGramsPerUnit(e.target.value)} className="w-full px-2 py-1.5 rounded-lg border border-slate-300 text-xs font-bold" />
        </div>
        <div>
          <label className="text-[10px] font-bold text-slate-600 block mb-0.5">{tr('وزن الكيس (كجم)', 'Bag (kg)')}</label>
          <input type="number" min="1" value={bagWeightKg} onChange={(e) => setBagWeightKg(Number(e.target.value))} className="w-full px-2 py-1.5 rounded-lg border border-slate-300 text-xs font-bold" />
        </div>
        <div>
          <label className="text-[10px] font-bold text-slate-600 block mb-0.5">{tr('سعر الكيس', 'Bag price')}</label>
          <input type="number" min="0" value={bagPrice} onChange={(e) => setBagPrice(e.target.value)} className="w-full px-2 py-1.5 rounded-lg border border-slate-300 text-xs font-bold" />
        </div>
      </div>
      {totalKg > 0 && (
        <div className="flex items-center justify-between bg-white rounded-lg p-2 border border-emerald-200">
          <span className="text-xs text-slate-600">
            {num(totalKg, 1)} {tr('كجم', 'kg')} ≈ {num(bagsNeeded, 1)} {tr('كيس', 'bags')}
          </span>
          <button
            type="button"
            onClick={() => onApply(Math.round(amount), `${num(totalKg, 1)} ${tr('كجم', 'kg')} (${num(bagsNeeded, 1)} ${tr('كيس', 'bags')})`)}
            className="text-[11px] font-bold bg-emerald-700 text-white px-2.5 py-1 rounded-lg"
          >
            {tr(`استخدم ${Math.round(amount).toLocaleString()} ر.س`, `Use ${Math.round(amount).toLocaleString()} SAR`)}
          </button>
        </div>
      )}
    </div>
  );
};

// ==========================================
// تكلفة وحدة الإنتاج — البيوت المحمية (فلين) والبساتين (صناديق)
// الإنتاج (طن) = عدد الوحدات × الوزن ÷ 1000، والسعر للوحدة
// ==========================================
const boxProductionTons = (u) =>
  u.productionMode !== 'manual' && Number(u.boxesCount) > 0 ? calcTonsFromBags(u.boxesCount, u.boxWeightKg) : Number(u.productionTons) || 0;

const BoxUnitCostCard = ({ u, expenses, onUpdate, unit, units, tr, num, money }) => {
  const count = Number(u.boxesCount) || 0;
  const calcTons = calcTonsFromBags(count, u.boxWeightKg);
  const tons = boxProductionTons(u);
  const showAdopt = count > 0 && u.productionMode === 'manual' && calcTons !== tons;
  const uc = calcUnitCost({ expenses, tons, bagWeightKg: Number(u.boxWeightKg) || 0, price: Number(u.sellingPricePerBox) || 0, priceUnit: 'unit' });
  const setProd = (patch) => onUpdate({ ...patch, productionTons: boxProductionTons({ ...u, ...patch }) });
  const lbl = { color: '#8ee6b9' };
  const smallInput = 'w-full px-3 py-3 rounded-[14px] bg-white text-slate-900 font-bold text-lg tabular-nums text-right border-0';

  return (
    <div className="rounded-3xl p-5 text-white space-y-4" style={{ background: 'linear-gradient(135deg,#1d5a33,#04281d)' }}>
      <h4 className="text-[22px] font-extrabold">{tr('تكلفة وحدة الإنتاج', 'Unit production cost')}</h4>
      <div>
        <label className="text-[15px] font-bold block mb-1.5" style={lbl}>{tr('إجمالي الإنتاج (طن)', 'Production (tons)')}</label>
        <input type="number" min="0" step="0.01" dir="ltr" value={tons || ''} onChange={(e) => onUpdate({ productionTons: Number(e.target.value), productionMode: 'manual' })} className="w-full px-4 py-[18px] rounded-[18px] bg-white text-slate-900 font-bold text-lg tabular-nums text-right border-0" />
      </div>
      {showAdopt && (
        <div className="flex items-center justify-between gap-2.5 flex-wrap text-sm" style={{ color: '#cfeee0' }}>
          <span>{tr('المحسوب من', 'Calculated from')} {units}: <b className="text-white tabular-nums">{calcTons}</b> {tr('طن', 't')}</span>
          <button onClick={() => onUpdate({ productionMode: 'auto', productionTons: calcTons })} className="text-[13px] font-extrabold text-slate-900 rounded-[10px] px-3 py-1.5" style={{ background: '#f9bf22' }}>
            {tr('اعتماد المحسوب', 'Use calculated')}
          </button>
        </div>
      )}
      <div className="grid grid-cols-3 gap-2 items-end">
        <div className="min-w-0">
          <label className="text-xs font-bold block mb-1.5 truncate" style={lbl}>{tr('عدد', 'No. of')} {units}</label>
          <input type="number" min="0" step="1" dir="ltr" value={count || ''} onChange={(e) => setProd({ boxesCount: Number(e.target.value) })} className={smallInput} />
        </div>
        <div className="min-w-0">
          <label className="text-xs font-bold block mb-1.5 truncate" style={lbl}>{tr('وزن', 'Weight of')} {unit} ({tr('كجم', 'kg')})</label>
          <input type="number" min="0" step="0.1" dir="ltr" value={u.boxWeightKg} onChange={(e) => setProd({ boxWeightKg: Number(e.target.value) })} className={smallInput} />
        </div>
        <div className="min-w-0">
          <label className="text-xs font-bold block mb-1.5 truncate" style={lbl}>{tr('سعر', 'Price of')} {unit}</label>
          <input type="number" min="0" step="0.01" dir="ltr" value={u.sellingPricePerBox} onChange={(e) => onUpdate({ sellingPricePerBox: Number(e.target.value) })} className={smallInput} />
        </div>
      </div>
      {!uc ? (
        <p className="text-[15px] text-center flex items-center justify-center gap-2" style={lbl}>
          <Info className="w-4 h-4" />
          {tr(`أدخل عدد ${units} أو الإنتاج لحساب التكلفة`, 'Enter count or production to compute cost')}
        </p>
      ) : (
        <div className="grid grid-cols-2 gap-2">
          {[
            [tr('تكلفة الطن', 'Cost/ton'), money(uc.costPerTon), ''],
            [`${tr('تكلفة', 'Cost/')} ${unit}`, uc.costPerUnit ? `${num(uc.costPerUnit, 2)} ر.س` : '—', ''],
            [tr('الإيراد المتوقع', 'Expected revenue'), money(uc.revenue), ''],
            [tr('صافي الربح المتوقع', 'Expected net profit'), money(uc.profit), uc.profit >= 0 ? '#7df0b0' : '#ff9b9b']
          ].map(([k, v, c]) => (
            <div key={k} className="rounded-[14px] p-3 min-w-0" style={{ background: 'rgba(255,255,255,.08)' }}>
              <span className="block text-xs font-bold" style={{ color: '#a9d9c0' }}>{k}</span>
              <b className="block text-lg mt-0.5 tabular-nums" style={c ? { color: c } : undefined}>{v}</b>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

// ==========================================
// التطبيق الرئيسي
// ==========================================

export default function App() {
  const [saved] = useState(loadSavedState);
  const [lang, setLang] = useState(saved?.lang ?? 'ar');
  const isRTL = lang === 'ar';
  const tr = (ar, en) => (isRTL ? ar : en);
  const money = (v) => formatCurrency(v, lang);
  const num = (v, d = 0) => formatNumber(v, lang, d);
  const Chevron = isRTL ? ChevronLeft : ChevronRight;

  const [farms, setFarms] = useState(saved?.farms ?? INITIAL_FARMS);
  const [pivots, setPivots] = useState(() =>
    (saved?.pivots ?? INITIAL_PIVOTS).map((p) => (p.areaMode === 'auto' ? { ...p, actualMeasuredArea: calcPivotGeometry(p).sectorHa } : p))
  );
  const [editPivotId, setEditPivotId] = useState(null);
  const [greenhouses, setGreenhouses] = useState(saved?.greenhouses ?? INITIAL_GREENHOUSES);
  const [orchards, setOrchards] = useState(saved?.orchards ?? INITIAL_ORCHARDS);
  const [transactions, setTransactions] = useState(saved?.transactions ?? INITIAL_TRANSACTIONS);
  const [farmerProfile, setFarmerProfile] = useState(saved?.farmerProfile ?? DEFAULT_PROFILE);

  const [savedAt, setSavedAt] = useState(null);
  const [storageOk, setStorageOk] = useState(true);
  const [activeTab, setActiveTab] = useState('home');
  const [selectedFarmId, setSelectedFarmId] = useState('all');
  const [openPivotId, setOpenPivotId] = useState(null);
  const [openGhId, setOpenGhId] = useState(null);
  const [openOrcId, setOpenOrcId] = useState(null);
  const [showOnboarding, setShowOnboarding] = useState(!saved?.farmerProfile?.registered);
  useEffect(() => { retryPendingLead(); }, []);
  const [quickModal, setQuickModal] = useState(null); // 'tx' | 'addPivot' | 'addGh' | 'addOrc'
  const [toastMessage, setToastMessage] = useState(null);
  const toastTimer = useRef(null);

  // ---------- الوضع الداكن/الفاتح ----------
  const [darkMode, setDarkMode] = useState(() => {
    try {
      const t = window.localStorage.getItem('agri-theme');
      if (t) return t === 'dark';
      return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
    } catch {
      return false;
    }
  });
  useEffect(() => {
    try {
      document.documentElement.classList.toggle('dark', darkMode);
      window.localStorage.setItem('agri-theme', darkMode ? 'dark' : 'light');
    } catch {}
  }, [darkMode]);
  const importInputRef = useRef(null);

  useEffect(() => {
    const id = setTimeout(() => {
      try {
        window.localStorage.setItem(STORAGE_KEY, JSON.stringify({ version: STORAGE_VERSION, lang, farms, pivots, greenhouses, orchards, transactions, farmerProfile }));
        setSavedAt(new Date());
        setStorageOk(true);
      } catch {
        setStorageOk(false);
      }
    }, 400);
    return () => clearTimeout(id);
  }, [lang, farms, pivots, greenhouses, orchards, transactions, farmerProfile]);

  const showToast = (msg) => {
    setToastMessage(msg);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToastMessage(null), 3000);
  };

  const enabledTypes = farmerProfile.enabledTypes || [];
  const byFarm = (list) => (selectedFarmId === 'all' ? list : list.filter((x) => x.farmId === selectedFarmId));
  const filteredPivots = useMemo(() => byFarm(pivots), [pivots, selectedFarmId]);
  const filteredGreenhouses = useMemo(() => byFarm(greenhouses), [greenhouses, selectedFarmId]);
  const filteredOrchards = useMemo(() => byFarm(orchards), [orchards, selectedFarmId]);
  const filteredTransactions = useMemo(() => byFarm(transactions), [transactions, selectedFarmId]);

  const summaryStats = useMemo(() => {
    const totalRevenue = sumAmount(filteredTransactions.filter((t) => t.type === 'revenue'));
    const totalExpense = sumAmount(filteredTransactions.filter((t) => t.type === 'expense'));
    const receivables = filteredTransactions.filter(isReceivable);
    const payables = filteredTransactions.filter(isPayable);
    return {
      totalRevenue,
      totalExpense,
      netProfit: totalRevenue - totalExpense,
      receivablesAmount: sumAmount(receivables),
      receivablesCount: receivables.length,
      payablesAmount: sumAmount(payables),
      payablesCount: payables.length
    };
  }, [filteredTransactions]);

  // ---------- Pivot handlers ----------
  const updatePivot = (id, patch) => {
    setPivots((prev) =>
      prev.map((p) => {
        if (p.id !== id) return p;
        const u = { ...p, ...patch };
        const touchesGeometry = GEOMETRY_KEYS.some((k) => k in patch);
        if ('actualMeasuredArea' in patch && !('areaMode' in patch)) u.areaMode = 'manual';
        else if (touchesGeometry && u.areaMode !== 'manual') u.actualMeasuredArea = calcPivotGeometry(u).sectorHa;
        return u;
      })
    );
  };
  const changePivotCategory = (pivot, cat) => {
    if ((pivot.cropCategory || 'grains') === cat) return;
    const next = { ...pivot, cropCategory: cat, ...CATEGORY_DEFAULTS[cat] };
    updatePivot(pivot.id, { cropCategory: cat, ...CATEGORY_DEFAULTS[cat], productionTons: pivotProductionTons(next) });
  };
  // عدد الأكياس / الوزن: لو الإنتاج تلقائي يتحدث الطن معهم
  const updatePivotProduction = (pivot, patch) => {
    const next = { ...pivot, ...patch };
    updatePivot(pivot.id, { ...patch, productionTons: pivotProductionTons(next) });
  };

  const handleAddPivot = (data) => {
    const id = `piv-${Date.now()}`;
    const cat = data.cropCategory || 'grains';
    setPivots((prev) => [
      {
        id,
        farmId: selectedFarmId !== 'all' ? selectedFarmId : farms[0]?.id,
        ...data,
        name: data.name || tr(`رشاش جديد ${prev.length + 1}`, `New pivot ${prev.length + 1}`),
        currentCrop: data.currentCrop || '—',
        cropCategory: cat,
        productionTons: 0,
        ...CATEGORY_DEFAULTS[cat],
        status: 'يعمل حالياً'
      },
      ...prev
    ]);
    setQuickModal(null);
    setOpenPivotId(id);
    setActiveTab('pivots');
    showToast(tr('تمت إضافة الرشاش', 'Pivot added'));
  };

  const handleEditPivot = (data) => {
    const p = pivots.find((x) => x.id === editPivotId);
    if (!p) return;
    const catChanged = (p.cropCategory || 'grains') !== data.cropCategory;
    updatePivot(p.id, {
      ...data,
      name: data.name || p.name,
      currentCrop: data.currentCrop || '—',
      ...(catChanged ? CATEGORY_DEFAULTS[data.cropCategory] : {})
    });
    setEditPivotId(null);
    showToast(tr('تم حفظ التعديلات', 'Changes saved'));
  };

  // ---------- Greenhouse handlers ----------
  const updateGreenhouse = (id, patch) => setGreenhouses((prev) => prev.map((g) => (g.id === id ? { ...g, ...patch } : g)));
  const addHall = (ghId) => {
    setGreenhouses((prev) =>
      prev.map((g) => (g.id === ghId ? { ...g, halls: [...(g.halls || []), { id: `hall-${Date.now()}`, name: tr(`صالة ${(g.halls?.length || 0) + 1}`, `Hall ${(g.halls?.length || 0) + 1}`), rows: 10, rowLength: 50, plantsPerRow: 20 }] } : g))
    );
  };
  const updateHall = (ghId, hallId, patch) =>
    setGreenhouses((prev) => prev.map((g) => (g.id === ghId ? { ...g, halls: g.halls.map((h) => (h.id === hallId ? { ...h, ...patch } : h)) } : g)));
  const removeHall = (ghId, hallId) => setGreenhouses((prev) => prev.map((g) => (g.id === ghId ? { ...g, halls: g.halls.filter((h) => h.id !== hallId) } : g)));

  const [ghForm, setGhForm] = useState({ name: '', farmId: farms[0]?.id, crop: '', rows: 10, plantsPerRow: 20 });
  const handleAddGreenhouse = (e) => {
    e.preventDefault();
    const id = `gh-${Date.now()}`;
    setGreenhouses((prev) => [
      {
        id,
        farmId: ghForm.farmId || farms[0]?.id,
        name: ghForm.name || tr(`بيت محمي جديد ${prev.length + 1}`, `New greenhouse ${prev.length + 1}`),
        crop: ghForm.crop || '—',
        variety: '',
        plantingDate: todayISO(),
        halls: [{ id: `hall-${Date.now()}`, name: tr('صالة 1', 'Hall 1'), rows: Number(ghForm.rows) || 1, rowLength: 50, plantsPerRow: Number(ghForm.plantsPerRow) || 1 }],
        productionTons: 0,
        boxWeightKg: 5,
        sellingPricePerBox: 0
      },
      ...prev
    ]);
    setQuickModal(null);
    setOpenGhId(id);
    setActiveTab('greenhouses');
    showToast(tr('تمت إضافة البيت المحمي', 'Greenhouse added'));
    setGhForm((f) => ({ ...f, name: '', crop: '' }));
  };

  // ---------- Orchard handlers ----------
  const updateOrchard = (id, patch) => setOrchards((prev) => prev.map((o) => (o.id === id ? { ...o, ...patch } : o)));
  const addVariety = (orcId) => {
    setOrchards((prev) =>
      prev.map((o) => (o.id === orcId ? { ...o, varieties: [...(o.varieties || []), { id: `var-${Date.now()}`, treeType: tr('صنف جديد', 'New variety'), variety: '', treeCount: 100, treeAge: 1 }] } : o))
    );
  };
  const updateVariety = (orcId, varId, patch) =>
    setOrchards((prev) => prev.map((o) => (o.id === orcId ? { ...o, varieties: o.varieties.map((v) => (v.id === varId ? { ...v, ...patch } : v)) } : o)));
  const removeVariety = (orcId, varId) => setOrchards((prev) => prev.map((o) => (o.id === orcId ? { ...o, varieties: o.varieties.filter((v) => v.id !== varId) } : o)));

  const [orcForm, setOrcForm] = useState({ name: '', farmId: farms[0]?.id, treeType: '', treeCount: 500 });
  const handleAddOrchard = (e) => {
    e.preventDefault();
    const id = `orc-${Date.now()}`;
    setOrchards((prev) => [
      {
        id,
        farmId: orcForm.farmId || farms[0]?.id,
        name: orcForm.name || tr(`بستان جديد ${prev.length + 1}`, `New orchard ${prev.length + 1}`),
        varieties: [{ id: `var-${Date.now()}`, treeType: orcForm.treeType || tr('نخيل', 'Palms'), variety: '', treeCount: Number(orcForm.treeCount) || 1, treeAge: 1 }],
        productionTons: 0,
        boxWeightKg: 5,
        sellingPricePerBox: 0
      },
      ...prev
    ]);
    setQuickModal(null);
    setOpenOrcId(id);
    setActiveTab('orchards');
    showToast(tr('تمت إضافة البستان', 'Orchard added'));
    setOrcForm((f) => ({ ...f, name: '', treeType: '' }));
  };

  // ---------- Transactions ----------
  const blankTx = (overrides = {}) => ({
    type: 'expense',
    category: 'أسمدة',
    unitType: '',
    unitId: '',
    title: '',
    date: todayISO(),
    amount: '',
    quantityLabel: '',
    invoiceNo: '',
    paymentMethod: 'تحويل بنكي',
    notes: '',
    ...overrides
  });
  const [txForm, setTxForm] = useState(() => blankTx());
  const openTxModal = (overrides) => {
    setTxForm(blankTx(overrides));
    setQuickModal('tx');
  };

  const allUnitOptions = useMemo(
    () => [
      ...pivots.map((p) => ({ unitType: 'pivot', unitId: p.id, farmId: p.farmId, label: `${tr('رشاش', 'Pivot')}: ${p.name}` })),
      ...greenhouses.map((g) => ({ unitType: 'greenhouse', unitId: g.id, farmId: g.farmId, label: `${tr('بيت محمي', 'GH')}: ${g.name}` })),
      ...orchards.map((o) => ({ unitType: 'orchard', unitId: o.id, farmId: o.farmId, label: `${tr('بستان', 'Orchard')}: ${o.name}` })),
      { unitType: '', unitId: '', farmId: '', label: tr('عام (بدون وحدة)', 'General (no unit)') }
    ],
    [pivots, greenhouses, orchards, lang]
  );

  const handleAddTransaction = (e) => {
    e.preventDefault();
    const amount = Number(txForm.amount);
    if (!txForm.title.trim() || !(amount > 0)) return;
    const unit = allUnitOptions.find((o) => o.unitType === txForm.unitType && o.unitId === txForm.unitId);
    const onCredit = txForm.paymentMethod.includes('آجل');
    const isRevenue = txForm.type === 'revenue';
    const newTx = {
      id: `trx-${Date.now()}`,
      type: txForm.type,
      category: txForm.category,
      title: txForm.title.trim(),
      farmId: unit?.farmId || (selectedFarmId !== 'all' ? selectedFarmId : farms[0]?.id),
      unitType: txForm.unitType || null,
      unitId: txForm.unitId || null,
      date: txForm.date || todayISO(),
      amount,
      quantityLabel: txForm.quantityLabel,
      invoiceNo: txForm.invoiceNo || `${isRevenue ? 'INV' : 'EXP'}-${String(Date.now()).slice(-6)}`,
      paymentMethod: txForm.paymentMethod,
      status: onCredit ? (isRevenue ? 'مستحق للتحصيل' : 'ذمم دائنة') : isRevenue ? 'محصل' : 'مدفوع',
      notes: txForm.notes
    };
    setTransactions((prev) => [newTx, ...prev]);
    setQuickModal(null);
    showToast(`${isRevenue ? tr('تم تسجيل إيراد', 'Revenue recorded') : tr('تم تسجيل مصروف', 'Expense recorded')}: ${money(amount)}`);
  };

  const handleDeleteTransaction = (id) => {
    setTransactions((prev) => prev.filter((t) => t.id !== id));
    showToast(tr('تم حذف القيد', 'Entry deleted'));
  };
  const settleTransaction = (id) => {
    setTransactions((prev) => prev.map((t) => (t.id === id ? { ...t, status: t.type === 'revenue' ? 'محصل' : 'مدفوع' } : t)));
    showToast(tr('تم تسجيل السداد/التحصيل', 'Settled'));
  };

  // ---------- ملخص المزرعة لصاحب التطبيق ----------
  useEffect(() => {
    if (!farmerProfile?.registered || !farmerProfile?.phone) return;
    const id = setTimeout(() => {
      const revenue = sumAmount(transactions.filter((t) => t.type === 'revenue'));
      const expense = sumAmount(transactions.filter((t) => t.type === 'expense'));
      sendSummaryIfChanged({
        phone: normalizePhone(farmerProfile.phone),
        name: farmerProfile.name || '',
        farms: farms.map((f) => f.name).join('، '),
        pivots: pivots.length,
        greenhouses: greenhouses.length,
        orchards: orchards.length,
        txCount: transactions.length,
        revenue: Math.round(revenue),
        expense: Math.round(expense),
        net: Math.round(revenue - expense)
      });
    }, 15000);
    return () => clearTimeout(id);
  }, [farmerProfile, farms, pivots, greenhouses, orchards, transactions]);

  // ---------- Onboarding ----------
  const [obFarmName, setObFarmName] = useState('');
  const [obName, setObName] = useState('');
  const [obPhone, setObPhone] = useState('');
  const [obTypes, setObTypes] = useState(DEFAULT_PROFILE.enabledTypes);
  const obValid = obTypes.length > 0 && obName.trim().length >= 2 && isValidPhone(obPhone);
  const completeOnboarding = () => {
    if (!obValid) return;
    const phone = normalizePhone(obPhone);
    sendLead({
      name: obName.trim(),
      phone,
      farm: obFarmName.trim(),
      types: obTypes.map((id) => UNIT_TYPES.find((u) => u.id === id)?.label || id),
      lang,
      ua: navigator.userAgent
    });
    const onlyDemo = [farms, pivots, greenhouses, orchards, transactions].every((list) => list.every(isDemo));
    if (onlyDemo) {
      // عميل جديد: يبدأ ببيانات فارغة بدل البيانات التجريبية
      const f = { id: `farm-${Date.now()}`, name: obFarmName.trim() || 'مزرعتي', location: '' };
      setFarms([f]);
      setPivots([]);
      setGreenhouses([]);
      setOrchards([]);
      setTransactions([]);
      setSelectedFarmId(f.id);
      setFarmerProfile((p) => ({ ...p, name: obName.trim(), phone, city: '', registered: true, enabledTypes: obTypes }));
    } else {
      if (obFarmName.trim()) {
        const f = { id: `farm-${Date.now()}`, name: obFarmName.trim(), location: farmerProfile.city };
        setFarms((prev) => [f, ...prev]);
        setSelectedFarmId(f.id);
      }
      setFarmerProfile((p) => ({ ...p, name: obName.trim(), phone, registered: true, enabledTypes: obTypes }));
    }
    setShowOnboarding(false);
    showToast(tr('مرحباً بك! تم إعداد مزرعتك', 'Welcome! Your farm is set up'));
  };

  // ---------- Backup ----------
  const exportBackup = () => {
    const blob = new Blob([JSON.stringify({ version: STORAGE_VERSION, lang, farms, pivots, greenhouses, orchards, transactions, farmerProfile }, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `agri-erp-backup-${todayISO()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };
  const importBackup = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const d = JSON.parse(reader.result);
        if (d.version !== STORAGE_VERSION || !Array.isArray(d.farms) || !Array.isArray(d.pivots) || !Array.isArray(d.greenhouses) || !Array.isArray(d.orchards) || !Array.isArray(d.transactions) || !d.farmerProfile) throw new Error();
        setFarms(d.farms);
        setPivots(d.pivots);
        setGreenhouses(d.greenhouses);
        setOrchards(d.orchards);
        setTransactions(d.transactions);
        setFarmerProfile(d.farmerProfile);
        showToast(tr('تمت الاستعادة بنجاح', 'Restored successfully'));
      } catch {
        showToast(tr('الملف غير صالح', 'Invalid file'));
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };
  const resetDemoData = () => {
    if (!window.confirm(tr('سيتم حذف بياناتك واستعادة البيانات التجريبية. متابعة؟', 'This will delete your data and restore demo data. Continue?'))) return;
    setFarms(INITIAL_FARMS);
    setPivots(INITIAL_PIVOTS);
    setGreenhouses(INITIAL_GREENHOUSES);
    setOrchards(INITIAL_ORCHARDS);
    setTransactions(INITIAL_TRANSACTIONS);
    setFarmerProfile((p) => ({ ...DEFAULT_PROFILE, name: p.name, phone: p.phone, registered: p.registered }));
    setSelectedFarmId('all');
    showToast(tr('تمت استعادة البيانات التجريبية', 'Demo data restored'));
  };

  const hasDemoData = [farms, pivots, greenhouses, orchards, transactions].some((list) => list.some(isDemo));
  const removeDemoData = () => {
    if (!window.confirm(tr('سيتم حذف البيانات التجريبية فقط وتبقى بياناتك. متابعة؟', 'Only demo data will be deleted; your data stays. Continue?'))) return;
    const removedUnitIds = new Set([...pivots, ...greenhouses, ...orchards].filter(isDemo).map((u) => u.id));
    const keptPivots = pivots.filter((x) => !isDemo(x));
    const keptGreenhouses = greenhouses.filter((x) => !isDemo(x));
    const keptOrchards = orchards.filter((x) => !isDemo(x));
    const keptTransactions = transactions.filter((t) => !isDemo(t) && !(t.unitId && removedUnitIds.has(t.unitId)));
    // لا نحذف مزرعة تجريبية لو العميل أضاف عليها وحدات أو قيود خاصة به
    const usedFarmIds = new Set([...keptPivots, ...keptGreenhouses, ...keptOrchards, ...keptTransactions].map((x) => x.farmId));
    let keptFarms = farms.filter((f) => !isDemo(f) || usedFarmIds.has(f.id));
    let newFarmId = null;
    if (keptFarms.length === 0) {
      const f = { id: `farm-${Date.now()}`, name: 'مزرعتي', location: '' };
      keptFarms = [f];
      newFarmId = f.id;
    }
    setFarms(keptFarms);
    setPivots(keptPivots);
    setGreenhouses(keptGreenhouses);
    setOrchards(keptOrchards);
    setTransactions(keptTransactions);
    if (newFarmId) setSelectedFarmId(newFarmId);
    else if (selectedFarmId !== 'all' && !keptFarms.some((f) => f.id === selectedFarmId)) setSelectedFarmId('all');
    if (farmerProfile.city === 'القصيم - بريدة') setFarmerProfile((p) => ({ ...p, city: '' }));
    showToast(tr('تم حذف البيانات التجريبية', 'Demo data deleted'));
  };

  const savedLabel = !storageOk
    ? tr('الحفظ غير متاح', 'Save unavailable')
    : savedAt
    ? `${tr('محفوظ', 'Saved')} ${savedAt.toLocaleTimeString(isRTL ? 'ar-SA' : 'en-US', { hour: '2-digit', minute: '2-digit' })}`
    : tr('جاري التحميل', 'Loading');

  const bottomNavItems = [
    { id: 'home', label: tr('الرئيسية', 'Home'), icon: Home },
    ...(enabledTypes.includes('pivots') ? [{ id: 'pivots', label: tr('رشاشات', 'Pivots'), icon: Compass }] : []),
    ...(enabledTypes.includes('greenhouses') ? [{ id: 'greenhouses', label: tr('بيوت محمية', 'Houses'), icon: Package }] : []),
    ...(enabledTypes.includes('orchards') ? [{ id: 'orchards', label: tr('بساتين', 'Orchards'), icon: Trees }] : []),
    { id: 'settings', label: tr('الإعدادات', 'Settings'), icon: Settings }
  ];

  return (
    <div dir={isRTL ? 'rtl' : 'ltr'} className="min-h-screen bg-[#F8FAFC] text-slate-800 flex flex-col antialiased" style={{ fontFamily: "'Tajawal', system-ui, sans-serif" }}>
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-20">
        <div className="max-w-md mx-auto px-4 py-3 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0">
            <div className="w-9 h-9 rounded-xl bg-[#14532D] flex items-center justify-center shrink-0">
              <Compass className="w-5 h-5 text-emerald-300" />
            </div>
            <select value={selectedFarmId} onChange={(e) => setSelectedFarmId(e.target.value)} className="text-sm font-extrabold text-slate-800 bg-transparent focus:outline-none truncate">
              <option value="all">{tr('كل المزارع', 'All farms')}</option>
              {farms.map((f) => (
                <option key={f.id} value={f.id}>
                  {f.name}
                </option>
              ))}
            </select>
          </div>
          <div className="flex items-center gap-1.5 shrink-0">
            <button onClick={() => setDarkMode((d) => !d)} className="p-2 rounded-lg hover:bg-slate-100 text-slate-500" title={tr('الوضع الداكن/الفاتح', 'Dark/light mode')}>
              {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>
            <button onClick={() => setLang(lang === 'ar' ? 'en' : 'ar')} className="p-2 rounded-lg hover:bg-slate-100 text-slate-500">
              <Globe className="w-4 h-4" />
            </button>
            <button onClick={() => openTxModal()} className="bg-[#14532D] text-white p-2 rounded-lg">
              <Plus className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {toastMessage && (
        <div className="fixed bottom-20 inset-x-4 z-50 bg-emerald-900 text-white px-4 py-3 rounded-xl shadow-xl flex items-center gap-2.5 max-w-md mx-auto">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          <span className="text-sm font-medium">{toastMessage}</span>
        </div>
      )}

      <main className="flex-1 max-w-md w-full mx-auto px-4 py-5 pb-24 space-y-5">
        {/* ================= HOME ================= */}
        {activeTab === 'home' && (
          <div className="space-y-5">
            <p className="text-xs text-slate-500">
              {savedLabel} • {storageOk ? <CheckCircle2 className="w-3 h-3 inline text-emerald-600" /> : <AlertTriangle className="w-3 h-3 inline text-rose-600" />}
            </p>

            <div className="bg-gradient-to-br from-[#0F3D23] to-[#14532D] text-white rounded-2xl p-5">
              <span className="text-xs text-emerald-200">{tr('صافي الربح', 'Net profit')}</span>
              <div className={`text-3xl font-extrabold mt-1 tabular-nums ${summaryStats.netProfit < 0 ? 'text-rose-300' : 'text-white'}`}>{money(summaryStats.netProfit)}</div>
              <div className="grid grid-cols-2 gap-2.5 mt-4 text-xs">
                <div className="p-3 rounded-xl bg-white/10">
                  <span className="text-emerald-200 block text-[11px]">{tr('الإيرادات', 'Revenue')}</span>
                  <span className="font-extrabold text-emerald-300 tabular-nums">{money(summaryStats.totalRevenue)}</span>
                </div>
                <div className="p-3 rounded-xl bg-white/10">
                  <span className="text-emerald-200 block text-[11px]">{tr('المصروفات', 'Expenses')}</span>
                  <span className="font-extrabold text-rose-300 tabular-nums">{money(summaryStats.totalExpense)}</span>
                </div>
                {summaryStats.receivablesCount > 0 && (
                  <div className="p-3 rounded-xl bg-white/10">
                    <span className="text-emerald-200 block text-[11px]">{tr('مستحقات لنا', 'Receivables')}</span>
                    <span className="font-extrabold text-sky-300 tabular-nums">{money(summaryStats.receivablesAmount)}</span>
                  </div>
                )}
                {summaryStats.payablesCount > 0 && (
                  <div className="p-3 rounded-xl bg-white/10">
                    <span className="text-emerald-200 block text-[11px]">{tr('ذمم علينا', 'Payables')}</span>
                    <span className="font-extrabold text-amber-300 tabular-nums">{money(summaryStats.payablesAmount)}</span>
                  </div>
                )}
              </div>
            </div>

            <div className="space-y-3">
              {enabledTypes.includes('pivots') && (
                <button onClick={() => setActiveTab('pivots')} className="w-full bg-white rounded-2xl p-4 border border-slate-200 flex items-center justify-between text-start">
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center"><Compass className="w-6 h-6" /></div>
                    <div>
                      <p className="text-sm font-extrabold text-slate-900">{tr('الرشاشات المحورية', 'Center pivots')}</p>
                      <p className="text-xs text-slate-500">{filteredPivots.length} {tr('رشاش', 'pivots')}</p>
                    </div>
                  </div>
                  <Chevron className="w-5 h-5 text-slate-400" />
                </button>
              )}
              {enabledTypes.includes('greenhouses') && (
                <button onClick={() => setActiveTab('greenhouses')} className="w-full bg-white rounded-2xl p-4 border border-slate-200 flex items-center justify-between text-start">
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-xl bg-sky-100 text-sky-800 flex items-center justify-center"><Package className="w-6 h-6" /></div>
                    <div>
                      <p className="text-sm font-extrabold text-slate-900">{tr('البيوت المحمية', 'Greenhouses')}</p>
                      <p className="text-xs text-slate-500">{filteredGreenhouses.length} {tr('بيت', 'houses')}</p>
                    </div>
                  </div>
                  <Chevron className="w-5 h-5 text-slate-400" />
                </button>
              )}
              {enabledTypes.includes('orchards') && (
                <button onClick={() => setActiveTab('orchards')} className="w-full bg-white rounded-2xl p-4 border border-slate-200 flex items-center justify-between text-start">
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center"><Trees className="w-6 h-6" /></div>
                    <div>
                      <p className="text-sm font-extrabold text-slate-900">{tr('البساتين والنخيل', 'Orchards')}</p>
                      <p className="text-xs text-slate-500">{filteredOrchards.length} {tr('بستان', 'orchards')}</p>
                    </div>
                  </div>
                  <Chevron className="w-5 h-5 text-slate-400" />
                </button>
              )}
              {enabledTypes.length === 0 && (
                <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 text-sm text-amber-900">
                  {tr('لم تُفعّل أي نوع وحدة زراعية. اذهب للإعدادات لتفعيل واحدة على الأقل.', 'No unit types enabled. Go to Settings to enable at least one.')}
                </div>
              )}
            </div>
          </div>
        )}

        {/* ================= PIVOTS ================= */}
        {activeTab === 'pivots' && !openPivotId && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-extrabold text-slate-900">{tr('الرشاشات المحورية', 'Center pivots')}</h2>
              <button onClick={() => setQuickModal('addPivot')} className="bg-[#14532D] text-white text-xs font-bold px-3 py-2 rounded-xl flex items-center gap-1">
                <Plus className="w-4 h-4" /> {tr('جديد', 'New')}
              </button>
            </div>
            {filteredPivots.map((p) => {
              const f = buildUnitFinance('pivot', p.id, transactions);
              return (
                <button key={p.id} onClick={() => setOpenPivotId(p.id)} className="w-full bg-white rounded-2xl p-4 border border-slate-200 text-start space-y-2">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-extrabold text-slate-900">{p.name}</h3>
                    <span className="text-xs font-bold text-emerald-800 tabular-nums">{p.actualMeasuredArea} {tr('هكتار', 'ha')}</span>
                  </div>
                  <p className="text-xs text-emerald-700 font-bold">{p.currentCrop}</p>
                  <div className="flex justify-between text-xs pt-2 border-t border-slate-100">
                    <span className="text-rose-700 font-bold tabular-nums">{tr('مصروفات', 'Exp')}: {money(f.expenses)}</span>
                    <span className="text-slate-500">{f.txList.length} {tr('قيد', 'entries')}</span>
                  </div>
                </button>
              );
            })}
            {filteredPivots.length === 0 && <p className="text-center text-sm text-slate-400 py-8">{tr('لا توجد رشاشات بعد', 'No pivots yet')}</p>}
          </div>
        )}

        {activeTab === 'pivots' && openPivotId && (() => {
          const p = pivots.find((x) => x.id === openPivotId);
          if (!p) return null;
          const f = buildUnitFinance('pivot', p.id, transactions);
          const geom = calcPivotGeometry(p);
          const isForage = p.cropCategory === 'forage';
          const unitWord = isForage ? tr('اللبنة', 'bale') : tr('الكيس', 'bag');
          const unitsWord = isForage ? tr('اللبنات', 'bales') : tr('الأكياس', 'bags');
          const bagsCount = Number(p.bagsCount) || 0;
          const calcTons = calcTonsFromBags(bagsCount, p.baleWeightKg);
          const prodTons = pivotProductionTons(p);
          const showAdopt = bagsCount > 0 && p.productionMode === 'manual' && calcTons !== prodTons;
          const uc = calcUnitCost({ expenses: f.expenses, tons: prodTons, bagWeightKg: Number(p.baleWeightKg) || 0, price: Number(p.marketPricePerUnit) || 0, priceUnit: isForage ? 'unit' : 'ton' });
          const costPerHa = p.actualMeasuredArea > 0 ? f.expenses / p.actualMeasuredArea : 0;

          return (
            <div className="space-y-4">
              <button onClick={() => setOpenPivotId(null)} className="flex items-center gap-1 text-sm font-bold text-slate-600">
                <ChevronRight className={`w-4 h-4 ${isRTL ? 'rotate-180' : ''}`} /> {tr('رجوع', 'Back')}
              </button>

              {/* عرض بيانات الرشاش */}
              <div className="bg-white rounded-[22px] p-4 border border-slate-200 space-y-4">
                <div className="flex items-center justify-between gap-2.5">
                  <h3 className="text-xl font-extrabold text-slate-900 min-w-0 break-words">{p.name}</h3>
                  <button onClick={() => setEditPivotId(p.id)} className="shrink-0 flex items-center gap-1 text-sm font-extrabold text-[#1a5632] bg-emerald-50 border border-emerald-500 rounded-xl px-3.5 py-1.5">
                    <Pencil className="w-3.5 h-3.5" /> {tr('تعديل', 'Edit')}
                  </button>
                </div>
                <PivotSvgVisualizer towers={p.towers} hasExtension={p.hasExtension} extensionLength={p.extensionLength} angle={p.operatingAngle} />
                <div className="grid grid-cols-3 gap-2">
                  <div className="bg-emerald-50 rounded-2xl px-2.5 py-3 text-center min-w-0">
                    <span className="block text-xs font-bold text-slate-500">{tr('المساحة المعتمدة', 'Area used')}</span>
                    <b className="block text-lg mt-0.5 text-[#1a5632] tabular-nums">{p.actualMeasuredArea} {tr('هـ', 'ha')}</b>
                  </div>
                  <div className="bg-slate-50 rounded-2xl px-2.5 py-3 text-center min-w-0">
                    <span className="block text-xs font-bold text-slate-500">{tr('الأبراج', 'Towers')}</span>
                    <b className="block text-lg mt-0.5 text-slate-900 tabular-nums">{p.towers}</b>
                  </div>
                  <div className="bg-slate-50 rounded-2xl px-2.5 py-3 text-center min-w-0">
                    <span className="block text-xs font-bold text-slate-500">{tr('الزاوية', 'Angle')}</span>
                    <b className="block text-lg mt-0.5 text-slate-900 tabular-nums">{p.operatingAngle}°</b>
                  </div>
                </div>
                <div className="flex flex-col text-[15px]">
                  {[
                    [tr('المحصول', 'Crop'), p.currentCrop || '—'],
                    [tr('نوع الإنتاج', 'Production type'), (() => { const c = PIVOT_CATEGORIES.find((x) => x.id === (p.cropCategory || 'grains')); return c ? tr(c.ar, c.en) : '—'; })()],
                    [tr('التوصيلة', 'Extension'), p.hasExtension ? `${Number(p.extensionLength) || 0} ${tr('م', 'm')}` : tr('لا يوجد', 'None')],
                    [tr('نصف القطر', 'Radius'), `${geom.radius} ${tr('م', 'm')}`]
                  ].map(([k, v]) => (
                    <div key={k} className="flex justify-between gap-3 py-2.5 border-b border-dashed border-slate-200">
                      <span className="text-slate-500">{k}</span>
                      <b className="font-bold text-slate-900 text-end">{v}</b>
                    </div>
                  ))}
                  <div className="flex justify-between gap-3 py-2.5">
                    <span className="text-slate-500">{tr('المحسوب هندسياً', 'Calculated')}</span>
                    <b className="font-bold text-slate-900 tabular-nums">
                      {geom.sectorHa} {tr('هـ', 'ha')}{' '}
                      {p.areaMode === 'manual' && <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-500">{tr('المعتمدة مقاسة يدوياً', 'Manually measured')}</span>}
                    </b>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <button onClick={() => openTxModal({ type: 'expense', unitType: 'pivot', unitId: p.id })} className="bg-rose-700 text-white text-xs font-extrabold py-2.5 rounded-xl flex items-center justify-center gap-1.5">
                  <ArrowDownRight className="w-4 h-4" /> {tr('مصروف', 'Expense')}
                </button>
                <button onClick={() => openTxModal({ type: 'revenue', category: 'مبيعات المحاصيل', unitType: 'pivot', unitId: p.id })} className="bg-[#14532D] text-white text-xs font-extrabold py-2.5 rounded-xl flex items-center justify-center gap-1.5">
                  <ArrowUpRight className="w-4 h-4" /> {tr('إيراد', 'Revenue')}
                </button>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200">
                  <span className="text-[11px] text-rose-900 block">{tr('المصروفات', 'Expenses')}</span>
                  <span className="text-lg font-extrabold text-rose-800 tabular-nums">{money(f.expenses)}</span>
                </div>
                <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200">
                  <span className="text-[11px] text-amber-900 block">{tr('تكلفة الهكتار', 'Cost/ha')}</span>
                  <span className="text-lg font-extrabold text-amber-900 tabular-nums">{money(costPerHa)}</span>
                </div>
                <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200">
                  <span className="text-[11px] text-emerald-900 block">{tr('الإيرادات', 'Revenue')}</span>
                  <span className="text-lg font-extrabold text-emerald-800 tabular-nums">{money(f.revenues)}</span>
                </div>
                <div className={`p-3.5 rounded-xl text-white ${f.netProfit >= 0 ? 'bg-[#14532D]' : 'bg-rose-950'}`}>
                  <span className="text-[11px] text-emerald-200 block">{tr('صافي الربح', 'Net')}</span>
                  <span className="text-lg font-extrabold tabular-nums">{money(f.netProfit)}</span>
                </div>
              </div>

              {/* تكلفة وحدة الإنتاج */}
              <div className="rounded-3xl p-5 text-white space-y-4" style={{ background: 'linear-gradient(135deg,#1d5a33,#04281d)' }}>
                <h4 className="text-[22px] font-extrabold">{tr('تكلفة وحدة الإنتاج', 'Unit production cost')}</h4>
                <div className="flex gap-1 p-1.5 rounded-2xl" style={{ background: '#06301f' }}>
                  {[{ id: 'grains', l: tr('حبوب', 'Grains') }, { id: 'forage', l: tr('أعلاف', 'Forage') }, { id: 'tubers', l: tr('درنيات', 'Tubers') }].map((m) => (
                    <button key={m.id} onClick={() => changePivotCategory(p, m.id)} className={`flex-1 py-2 rounded-xl text-[17px] font-extrabold ${(p.cropCategory || 'grains') === m.id ? 'text-slate-950' : 'text-white'}`} style={(p.cropCategory || 'grains') === m.id ? { background: '#f9bf22' } : undefined}>
                      {m.l}
                    </button>
                  ))}
                </div>
                <div>
                  <label className="text-[15px] font-bold block mb-1.5" style={{ color: '#8ee6b9' }}>{tr('إجمالي الإنتاج (طن)', 'Production (tons)')}</label>
                  <input type="number" min="0" step="0.01" dir="ltr" value={prodTons || ''} onChange={(e) => updatePivot(p.id, { productionTons: Number(e.target.value), productionMode: 'manual' })} className="w-full px-4 py-[18px] rounded-[18px] bg-white text-slate-900 font-bold text-lg tabular-nums text-right border-0" />
                </div>
                {showAdopt && (
                  <div className="flex items-center justify-between gap-2.5 flex-wrap text-sm" style={{ color: '#cfeee0' }}>
                    <span>{tr('المحسوب من', 'Calculated from')} {unitsWord}: <b className="text-white tabular-nums">{calcTons}</b> {tr('طن', 't')}</span>
                    <button onClick={() => updatePivot(p.id, { productionMode: 'auto', productionTons: calcTons })} className="text-[13px] font-extrabold text-slate-900 rounded-[10px] px-3 py-1.5" style={{ background: '#f9bf22' }}>
                      {tr('اعتماد المحسوب', 'Use calculated')}
                    </button>
                  </div>
                )}
                <div className="grid grid-cols-3 gap-2 items-end">
                  <div className="min-w-0">
                    <label className="text-xs font-bold block mb-1.5 truncate" style={{ color: '#8ee6b9' }}>{tr('عدد', 'No. of')} {unitsWord}</label>
                    <input type="number" min="0" step="1" dir="ltr" value={bagsCount || ''} onChange={(e) => updatePivotProduction(p, { bagsCount: Number(e.target.value) })} className="w-full px-3 py-3 rounded-[14px] bg-white text-slate-900 font-bold text-lg tabular-nums text-right border-0" />
                  </div>
                  <div className="min-w-0">
                    <label className="text-xs font-bold block mb-1.5 truncate" style={{ color: '#8ee6b9' }}>{tr('وزن', 'Weight of')} {unitWord} ({tr('كجم', 'kg')})</label>
                    <input type="number" min="0" step="0.1" dir="ltr" value={p.baleWeightKg} onChange={(e) => updatePivotProduction(p, { baleWeightKg: Number(e.target.value) })} className="w-full px-3 py-3 rounded-[14px] bg-white text-slate-900 font-bold text-lg tabular-nums text-right border-0" />
                  </div>
                  <div className="min-w-0">
                    <label className="text-xs font-bold block mb-1.5 truncate" style={{ color: '#8ee6b9' }}>{isForage ? tr('سعر اللبنة', 'Bale price') : tr('سعر الطن', 'Ton price')}</label>
                    <input type="number" min="0" step="0.01" dir="ltr" value={p.marketPricePerUnit} onChange={(e) => updatePivot(p.id, { marketPricePerUnit: Number(e.target.value) })} className="w-full px-3 py-3 rounded-[14px] bg-white text-slate-900 font-bold text-lg tabular-nums text-right border-0" />
                  </div>
                </div>
                {!uc ? (
                  <p className="text-[15px] text-center flex items-center justify-center gap-2" style={{ color: '#8ee6b9' }}>
                    <Info className="w-4 h-4" />
                    {tr('أدخل عدد الأكياس أو الإنتاج لحساب التكلفة', 'Enter bag count or production to compute cost')}
                  </p>
                ) : (
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      [tr('تكلفة الطن', 'Cost/ton'), money(uc.costPerTon), ''],
                      [`${tr('تكلفة', 'Cost/')} ${unitWord}`, uc.costPerUnit ? `${num(uc.costPerUnit, 2)} ر.س` : '—', ''],
                      [tr('الإيراد المتوقع', 'Expected revenue'), money(uc.revenue), ''],
                      [tr('صافي الربح المتوقع', 'Expected net profit'), money(uc.profit), uc.profit >= 0 ? '#7df0b0' : '#ff9b9b']
                    ].map(([k, v, c]) => (
                      <div key={k} className="rounded-[14px] p-3 min-w-0" style={{ background: 'rgba(255,255,255,.08)' }}>
                        <span className="block text-xs font-bold" style={{ color: '#a9d9c0' }}>{k}</span>
                        <b className="block text-lg mt-0.5 tabular-nums" style={c ? { color: c } : undefined}>{v}</b>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <Ledger txList={f.txList} tr={tr} num={num} money={money} onDelete={handleDeleteTransaction} onSettle={settleTransaction} />
            </div>
          );
        })()}

        {/* ================= GREENHOUSES ================= */}
        {activeTab === 'greenhouses' && !openGhId && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-extrabold text-slate-900">{tr('البيوت المحمية', 'Greenhouses')}</h2>
              <button onClick={() => setQuickModal('addGh')} className="bg-[#14532D] text-white text-xs font-bold px-3 py-2 rounded-xl flex items-center gap-1">
                <Plus className="w-4 h-4" /> {tr('جديد', 'New')}
              </button>
            </div>
            {filteredGreenhouses.map((g) => {
              const f = buildUnitFinance('greenhouse', g.id, transactions);
              const plants = greenhousePlantCount(g);
              return (
                <button key={g.id} onClick={() => setOpenGhId(g.id)} className="w-full bg-white rounded-2xl p-4 border border-slate-200 text-start space-y-2">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-extrabold text-slate-900">{g.name}</h3>
                    <span className="text-xs font-bold text-sky-800 tabular-nums">{num(plants)} {tr('شتلة', 'plants')}</span>
                  </div>
                  <p className="text-xs text-emerald-700 font-bold">{g.crop}</p>
                  <div className="flex justify-between text-xs pt-2 border-t border-slate-100">
                    <span className="text-rose-700 font-bold tabular-nums">{tr('مصروفات', 'Exp')}: {money(f.expenses)}</span>
                    <span className="text-slate-500">{(g.halls || []).length} {tr('صالة', 'halls')}</span>
                  </div>
                </button>
              );
            })}
            {filteredGreenhouses.length === 0 && <p className="text-center text-sm text-slate-400 py-8">{tr('لا توجد بيوت محمية بعد', 'No greenhouses yet')}</p>}
          </div>
        )}

        {activeTab === 'greenhouses' && openGhId && (() => {
          const g = greenhouses.find((x) => x.id === openGhId);
          if (!g) return null;
          const f = buildUnitFinance('greenhouse', g.id, transactions);
          const plants = greenhousePlantCount(g);
          const costPerPlant = plants > 0 ? f.expenses / plants : 0;

          return (
            <div className="space-y-4">
              <button onClick={() => setOpenGhId(null)} className="flex items-center gap-1 text-sm font-bold text-slate-600">
                <ChevronRight className={`w-4 h-4 ${isRTL ? 'rotate-180' : ''}`} /> {tr('رجوع', 'Back')}
              </button>

              <div className="bg-white rounded-2xl p-4 border border-slate-200 space-y-1">
                <input value={g.name} onChange={(e) => updateGreenhouse(g.id, { name: e.target.value })} className="text-lg font-extrabold text-slate-900 w-full focus:outline-none" />
                <input value={g.crop} onChange={(e) => updateGreenhouse(g.id, { crop: e.target.value })} className="text-sm text-emerald-700 font-bold w-full focus:outline-none" />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <button onClick={() => openTxModal({ type: 'expense', unitType: 'greenhouse', unitId: g.id })} className="bg-rose-700 text-white text-xs font-extrabold py-2.5 rounded-xl flex items-center justify-center gap-1.5">
                  <ArrowDownRight className="w-4 h-4" /> {tr('مصروف', 'Expense')}
                </button>
                <button onClick={() => openTxModal({ type: 'revenue', category: 'مبيعات المحاصيل', unitType: 'greenhouse', unitId: g.id })} className="bg-[#14532D] text-white text-xs font-extrabold py-2.5 rounded-xl flex items-center justify-center gap-1.5">
                  <ArrowUpRight className="w-4 h-4" /> {tr('إيراد', 'Revenue')}
                </button>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200">
                  <span className="text-[11px] text-rose-900 block">{tr('المصروفات', 'Expenses')}</span>
                  <span className="text-lg font-extrabold text-rose-800 tabular-nums">{money(f.expenses)}</span>
                </div>
                <div className="p-3.5 rounded-xl bg-sky-50 border border-sky-200">
                  <span className="text-[11px] text-sky-900 block">{tr('تكلفة الشتلة', 'Cost/plant')}</span>
                  <span className="text-lg font-extrabold text-sky-900 tabular-nums">{plants > 0 ? `${num(costPerPlant, 2)} ر.س` : '—'}</span>
                </div>
                <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200">
                  <span className="text-[11px] text-emerald-900 block">{tr('الإيرادات', 'Revenue')}</span>
                  <span className="text-lg font-extrabold text-emerald-800 tabular-nums">{money(f.revenues)}</span>
                </div>
                <div className={`p-3.5 rounded-xl text-white ${f.netProfit >= 0 ? 'bg-[#14532D]' : 'bg-rose-950'}`}>
                  <span className="text-[11px] text-emerald-200 block">{tr('صافي الربح', 'Net')}</span>
                  <span className="text-lg font-extrabold tabular-nums">{money(f.netProfit)}</span>
                </div>
              </div>

              {/* الصالات والشتلات */}
              <div className="bg-white rounded-2xl p-4 border border-slate-200 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-extrabold text-slate-900">{tr('الصالات والشتلات', 'Halls & plants')}</h4>
                  <span className="text-xs font-extrabold text-sky-800 bg-sky-50 px-2.5 py-1 rounded-lg tabular-nums">{num(plants)} {tr('شتلة', 'plants')}</span>
                </div>
                {(g.halls || []).map((h) => (
                  <div key={h.id} className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                    <div className="flex items-center justify-between gap-2">
                      <input value={h.name} onChange={(e) => updateHall(g.id, h.id, { name: e.target.value })} className="text-xs font-extrabold text-slate-800 bg-transparent flex-1 focus:outline-none" />
                      <button onClick={() => removeHall(g.id, h.id)} className="p-1 text-slate-400 hover:text-rose-600"><Trash2 className="w-3.5 h-3.5" /></button>
                    </div>
                    <div className="grid grid-cols-3 gap-2">
                      <div>
                        <label className="text-[10px] text-slate-500 block mb-0.5">{tr('عدد الخطوط', 'Rows')}</label>
                        <input type="number" min="0" value={h.rows} onChange={(e) => updateHall(g.id, h.id, { rows: Number(e.target.value) })} className="w-full px-2 py-1 rounded-lg border border-slate-300 text-xs font-bold tabular-nums" />
                      </div>
                      <div>
                        <label className="text-[10px] text-slate-500 block mb-0.5">{tr('طول الخط (م)', 'Row length (m)')}</label>
                        <input type="number" min="0" value={h.rowLength} onChange={(e) => updateHall(g.id, h.id, { rowLength: Number(e.target.value) })} className="w-full px-2 py-1 rounded-lg border border-slate-300 text-xs font-bold tabular-nums" />
                      </div>
                      <div>
                        <label className="text-[10px] text-slate-500 block mb-0.5">{tr('شتلة/خط', 'Plants/row')}</label>
                        <input type="number" min="0" value={h.plantsPerRow} onChange={(e) => updateHall(g.id, h.id, { plantsPerRow: Number(e.target.value) })} className="w-full px-2 py-1 rounded-lg border border-slate-300 text-xs font-bold tabular-nums" />
                      </div>
                    </div>
                    <p className="text-[11px] text-sky-800 font-bold">= {num((Number(h.rows) || 0) * (Number(h.plantsPerRow) || 0))} {tr('شتلة', 'plants')}</p>
                  </div>
                ))}
                <button onClick={() => addHall(g.id)} className="w-full py-2 rounded-xl border-2 border-dashed border-slate-300 text-xs font-bold text-slate-500 flex items-center justify-center gap-1">
                  <Plus className="w-3.5 h-3.5" /> {tr('إضافة صالة', 'Add hall')}
                </button>
              </div>

              {/* تكلفة وحدة الإنتاج (فلين) */}
              <BoxUnitCostCard u={g} expenses={f.expenses} onUpdate={(patch) => updateGreenhouse(g.id, patch)} unit={tr('الفلينة', 'box')} units={tr('الفلين', 'boxes')} tr={tr} num={num} money={money} />

              <Ledger txList={f.txList} tr={tr} num={num} money={money} onDelete={handleDeleteTransaction} onSettle={settleTransaction} />
            </div>
          );
        })()}

        {/* ================= ORCHARDS ================= */}
        {activeTab === 'orchards' && !openOrcId && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-extrabold text-slate-900">{tr('البساتين والنخيل', 'Orchards')}</h2>
              <button onClick={() => setQuickModal('addOrc')} className="bg-[#14532D] text-white text-xs font-bold px-3 py-2 rounded-xl flex items-center gap-1">
                <Plus className="w-4 h-4" /> {tr('جديد', 'New')}
              </button>
            </div>
            {filteredOrchards.map((o) => {
              const f = buildUnitFinance('orchard', o.id, transactions);
              const trees = orchardTreeCount(o);
              return (
                <button key={o.id} onClick={() => setOpenOrcId(o.id)} className="w-full bg-white rounded-2xl p-4 border border-slate-200 text-start space-y-2">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-extrabold text-slate-900">{o.name}</h3>
                    <span className="text-xs font-bold text-amber-800 tabular-nums">{num(trees)} {tr('شجرة', 'trees')}</span>
                  </div>
                  <p className="text-xs text-emerald-700 font-bold">{(o.varieties || []).map((v) => v.treeType).join(' • ')}</p>
                  <div className="flex justify-between text-xs pt-2 border-t border-slate-100">
                    <span className="text-rose-700 font-bold tabular-nums">{tr('مصروفات', 'Exp')}: {money(f.expenses)}</span>
                    <span className="text-slate-500">{(o.varieties || []).length} {tr('صنف', 'varieties')}</span>
                  </div>
                </button>
              );
            })}
            {filteredOrchards.length === 0 && <p className="text-center text-sm text-slate-400 py-8">{tr('لا توجد بساتين بعد', 'No orchards yet')}</p>}
          </div>
        )}

        {activeTab === 'orchards' && openOrcId && (() => {
          const o = orchards.find((x) => x.id === openOrcId);
          if (!o) return null;
          const f = buildUnitFinance('orchard', o.id, transactions);
          const trees = orchardTreeCount(o);
          const costPerTree = trees > 0 ? f.expenses / trees : 0;

          return (
            <div className="space-y-4">
              <button onClick={() => setOpenOrcId(null)} className="flex items-center gap-1 text-sm font-bold text-slate-600">
                <ChevronRight className={`w-4 h-4 ${isRTL ? 'rotate-180' : ''}`} /> {tr('رجوع', 'Back')}
              </button>

              <div className="bg-white rounded-2xl p-4 border border-slate-200">
                <input value={o.name} onChange={(e) => updateOrchard(o.id, { name: e.target.value })} className="text-lg font-extrabold text-slate-900 w-full focus:outline-none" />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <button onClick={() => openTxModal({ type: 'expense', unitType: 'orchard', unitId: o.id })} className="bg-rose-700 text-white text-xs font-extrabold py-2.5 rounded-xl flex items-center justify-center gap-1.5">
                  <ArrowDownRight className="w-4 h-4" /> {tr('مصروف', 'Expense')}
                </button>
                <button onClick={() => openTxModal({ type: 'revenue', category: 'مبيعات المحاصيل', unitType: 'orchard', unitId: o.id })} className="bg-[#14532D] text-white text-xs font-extrabold py-2.5 rounded-xl flex items-center justify-center gap-1.5">
                  <ArrowUpRight className="w-4 h-4" /> {tr('إيراد', 'Revenue')}
                </button>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200">
                  <span className="text-[11px] text-rose-900 block">{tr('المصروفات', 'Expenses')}</span>
                  <span className="text-lg font-extrabold text-rose-800 tabular-nums">{money(f.expenses)}</span>
                </div>
                <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200">
                  <span className="text-[11px] text-amber-900 block">{tr('تكلفة الشجرة', 'Cost/tree')}</span>
                  <span className="text-lg font-extrabold text-amber-900 tabular-nums">{trees > 0 ? `${num(costPerTree, 2)} ر.س` : '—'}</span>
                </div>
                <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200">
                  <span className="text-[11px] text-emerald-900 block">{tr('الإيرادات', 'Revenue')}</span>
                  <span className="text-lg font-extrabold text-emerald-800 tabular-nums">{money(f.revenues)}</span>
                </div>
                <div className={`p-3.5 rounded-xl text-white ${f.netProfit >= 0 ? 'bg-[#14532D]' : 'bg-rose-950'}`}>
                  <span className="text-[11px] text-emerald-200 block">{tr('صافي الربح', 'Net')}</span>
                  <span className="text-lg font-extrabold tabular-nums">{money(f.netProfit)}</span>
                </div>
              </div>

              {/* الأصناف والأشجار */}
              <div className="bg-white rounded-2xl p-4 border border-slate-200 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-extrabold text-slate-900">{tr('الأصناف والأشجار', 'Varieties & trees')}</h4>
                  <span className="text-xs font-extrabold text-amber-800 bg-amber-50 px-2.5 py-1 rounded-lg tabular-nums">{num(trees)} {tr('شجرة', 'trees')}</span>
                </div>
                {(o.varieties || []).map((v) => (
                  <div key={v.id} className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                    <div className="flex items-center justify-between gap-2">
                      <input value={v.treeType} onChange={(e) => updateVariety(o.id, v.id, { treeType: e.target.value })} className="text-xs font-extrabold text-slate-800 bg-transparent flex-1 focus:outline-none" />
                      <button onClick={() => removeVariety(o.id, v.id)} className="p-1 text-slate-400 hover:text-rose-600"><Trash2 className="w-3.5 h-3.5" /></button>
                    </div>
                    <input value={v.variety} onChange={(e) => updateVariety(o.id, v.id, { variety: e.target.value })} placeholder={tr('الصنف (اختياري)', 'Variety (optional)')} className="text-xs text-slate-600 bg-transparent w-full focus:outline-none" />
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="text-[10px] text-slate-500 block mb-0.5">{tr('عدد الأشجار', 'Tree count')}</label>
                        <input type="number" min="0" value={v.treeCount} onChange={(e) => updateVariety(o.id, v.id, { treeCount: Number(e.target.value) })} className="w-full px-2 py-1 rounded-lg border border-slate-300 text-xs font-bold tabular-nums" />
                      </div>
                      <div>
                        <label className="text-[10px] text-slate-500 block mb-0.5">{tr('عمر الأشجار (سنة)', 'Tree age (yrs)')}</label>
                        <input type="number" min="0" value={v.treeAge} onChange={(e) => updateVariety(o.id, v.id, { treeAge: Number(e.target.value) })} className="w-full px-2 py-1 rounded-lg border border-slate-300 text-xs font-bold tabular-nums" />
                      </div>
                    </div>
                  </div>
                ))}
                <button onClick={() => addVariety(o.id)} className="w-full py-2 rounded-xl border-2 border-dashed border-slate-300 text-xs font-bold text-slate-500 flex items-center justify-center gap-1">
                  <Plus className="w-3.5 h-3.5" /> {tr('إضافة صنف', 'Add variety')}
                </button>
              </div>

              {/* تكلفة وحدة الإنتاج (صناديق) */}
              <BoxUnitCostCard u={o} expenses={f.expenses} onUpdate={(patch) => updateOrchard(o.id, patch)} unit={tr('الصندوق', 'box')} units={tr('الصناديق', 'boxes')} tr={tr} num={num} money={money} />

              <Ledger txList={f.txList} tr={tr} num={num} money={money} onDelete={handleDeleteTransaction} onSettle={settleTransaction} />
            </div>
          );
        })()}

        {/* ================= SETTINGS ================= */}
        {activeTab === 'settings' && (
          <div className="space-y-5">
            <h2 className="text-lg font-extrabold text-slate-900">{tr('الإعدادات', 'Settings')}</h2>

            <div className="bg-white rounded-2xl p-4 border border-slate-200">
              <label className="flex items-center justify-between">
                <span className="flex items-center gap-2.5 text-sm font-bold text-slate-800">
                  {darkMode ? <Sun className="w-4.5 h-4.5" /> : <Moon className="w-4.5 h-4.5" />}
                  {tr('الوضع الداكن', 'Dark mode')}
                </span>
                <input type="checkbox" checked={darkMode} onChange={(e) => setDarkMode(e.target.checked)} className="w-5 h-5" />
              </label>
            </div>

            <div className="bg-white rounded-2xl p-4 border border-slate-200 space-y-3">
              <h3 className="text-sm font-extrabold text-slate-900">{tr('الملف الشخصي', 'Profile')}</h3>
              <input value={farmerProfile.name} onChange={(e) => setFarmerProfile({ ...farmerProfile, name: e.target.value })} placeholder={tr('الاسم', 'Name')} className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm" />
              <input value={farmerProfile.phone} onChange={(e) => setFarmerProfile({ ...farmerProfile, phone: e.target.value })} placeholder={tr('الجوال', 'Phone')} className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm font-mono" />
              <input value={farmerProfile.city} onChange={(e) => setFarmerProfile({ ...farmerProfile, city: e.target.value })} placeholder={tr('المدينة', 'City')} className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm" />
            </div>

            <div className="bg-white rounded-2xl p-4 border border-slate-200 space-y-2.5">
              <h3 className="text-sm font-extrabold text-slate-900">{tr('الوحدات الزراعية المفعّلة', 'Enabled unit types')}</h3>
              <p className="text-xs text-slate-500">{tr('اختر الأنواع التي تعمل بها، تظهر فقط هذه في الشريط السفلي', 'Pick the types you work with — only these show in the bottom bar')}</p>
              {UNIT_TYPES.map((ut) => {
                const Icon = ut.icon;
                const checked = enabledTypes.includes(ut.id);
                return (
                  <label key={ut.id} className={`flex items-center justify-between p-3 rounded-xl border ${checked ? 'border-emerald-500 bg-emerald-50' : 'border-slate-200'}`}>
                    <span className="flex items-center gap-2.5 text-sm font-bold text-slate-800">
                      <Icon className="w-4.5 h-4.5" /> {tr(ut.label, ut.labelEn)}
                    </span>
                    <input
                      type="checkbox"
                      checked={checked}
                      onChange={(e) => {
                        const next = e.target.checked ? [...enabledTypes, ut.id] : enabledTypes.filter((x) => x !== ut.id);
                        if (next.length === 0) return;
                        setFarmerProfile({ ...farmerProfile, enabledTypes: next });
                      }}
                      className="w-5 h-5"
                    />
                  </label>
                );
              })}
            </div>

            <div className="bg-white rounded-2xl p-4 border border-slate-200 space-y-2.5">
              <h3 className="text-sm font-extrabold text-slate-900">{tr('البيانات والنسخ الاحتياطي', 'Data & backup')}</h3>
              <button onClick={exportBackup} className="w-full bg-[#14532D] text-white text-xs font-bold px-4 py-2.5 rounded-xl flex items-center justify-center gap-1.5">
                <Download className="w-4 h-4" /> {tr('تصدير نسخة احتياطية', 'Export backup')}
              </button>
              <button onClick={() => importInputRef.current?.click()} className="w-full bg-white border border-slate-300 text-slate-800 text-xs font-bold px-4 py-2.5 rounded-xl flex items-center justify-center gap-1.5">
                <Upload className="w-4 h-4" /> {tr('استيراد نسخة', 'Import backup')}
              </button>
              <input ref={importInputRef} type="file" accept="application/json" className="hidden" onChange={importBackup} />
              {hasDemoData && (
                <button onClick={removeDemoData} className="w-full bg-amber-50 border border-amber-200 text-amber-800 text-xs font-bold px-4 py-2.5 rounded-xl flex items-center justify-center gap-1.5">
                  <Trash2 className="w-4 h-4" /> {tr('حذف البيانات التجريبية', 'Delete demo data')}
                </button>
              )}
              <button onClick={resetDemoData} className="w-full bg-rose-50 border border-rose-200 text-rose-800 text-xs font-bold px-4 py-2.5 rounded-xl flex items-center justify-center gap-1.5">
                <RotateCcw className="w-4 h-4" /> {tr('استعادة البيانات التجريبية', 'Reset demo data')}
              </button>
            </div>
          </div>
        )}
      </main>

      {/* Bottom nav */}
      <nav className="fixed bottom-0 inset-x-0 bg-white border-t border-slate-200 z-30 flex items-center justify-around py-2 px-1">
        {bottomNavItems.map((item) => {
          const Icon = item.icon;
          const active = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => {
                setActiveTab(item.id);
                setOpenPivotId(null);
                setOpenGhId(null);
                setOpenOrcId(null);
              }}
              className={`flex flex-col items-center gap-1 px-3 py-1 rounded-xl text-[11px] font-bold ${active ? 'text-[#14532D]' : 'text-slate-500'}`}
            >
              <Icon className="w-5 h-5" />
              <span>{item.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Quick action modal (tx) */}
      {quickModal === 'tx' && (
        <Modal onClose={() => setQuickModal(null)} title={txForm.type === 'revenue' ? tr('تسجيل إيراد', 'Record revenue') : tr('تسجيل مصروف', 'Record expense')}>
          <form onSubmit={handleAddTransaction} className="space-y-3">
            <div className="grid grid-cols-2 gap-2 bg-slate-100 p-1 rounded-xl">
              <button type="button" onClick={() => setTxForm({ ...txForm, type: 'expense', category: 'أسمدة' })} className={`py-2 rounded-lg text-xs font-bold ${txForm.type === 'expense' ? 'bg-rose-700 text-white' : 'text-slate-600'}`}>
                {tr('مصروف', 'Expense')}
              </button>
              <button type="button" onClick={() => setTxForm({ ...txForm, type: 'revenue', category: 'مبيعات المحاصيل' })} className={`py-2 rounded-lg text-xs font-bold ${txForm.type === 'revenue' ? 'bg-[#14532D] text-white' : 'text-slate-600'}`}>
                {tr('إيراد', 'Revenue')}
              </button>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">{tr('مركز التكلفة', 'Cost center')}</label>
              <select
                value={`${txForm.unitType}:${txForm.unitId}`}
                onChange={(e) => {
                  const [unitType, unitId] = e.target.value.split(':');
                  setTxForm({ ...txForm, unitType, unitId });
                }}
                className="w-full px-3 py-2 rounded-xl border border-emerald-400 text-sm font-bold bg-white"
              >
                {allUnitOptions.map((o) => (
                  <option key={`${o.unitType}:${o.unitId}`} value={`${o.unitType}:${o.unitId}`}>
                    {o.label}
                  </option>
                ))}
              </select>
            </div>

            {txForm.type === 'expense' && txForm.category === 'أسمدة' && txForm.unitType === 'greenhouse' && (
              <FertilizerHelper
                unitLabel={tr('شتلة', 'plant')}
                unitCount={greenhousePlantCount(greenhouses.find((g) => g.id === txForm.unitId) || {})}
                onApply={(amount, label) => setTxForm((f) => ({ ...f, amount, quantityLabel: label }))}
                tr={tr}
                num={num}
              />
            )}
            {txForm.type === 'expense' && txForm.category === 'أسمدة' && txForm.unitType === 'orchard' && (
              <FertilizerHelper
                unitLabel={tr('شجرة', 'tree')}
                unitCount={orchardTreeCount(orchards.find((o) => o.id === txForm.unitId) || {})}
                onApply={(amount, label) => setTxForm((f) => ({ ...f, amount, quantityLabel: label }))}
                tr={tr}
                num={num}
              />
            )}

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{tr('التصنيف', 'Category')}</label>
                <select value={txForm.category} onChange={(e) => setTxForm({ ...txForm, category: e.target.value })} className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm bg-white">
                  {txForm.type === 'expense' ? EXPENSE_CATEGORIES.map((c) => <option key={c.key}>{c.key}</option>) : ['مبيعات المحاصيل', 'إيرادات أخرى'].map((c) => <option key={c}>{c}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{tr('المبلغ (ر.س)', 'Amount')}</label>
                <input type="number" required min="0.01" step="0.01" value={txForm.amount} onChange={(e) => setTxForm({ ...txForm, amount: e.target.value })} className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm font-bold tabular-nums" />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">{tr('البيان', 'Description')}</label>
              <input type="text" required value={txForm.title} onChange={(e) => setTxForm({ ...txForm, title: e.target.value })} className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm" />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{tr('التاريخ', 'Date')}</label>
                <input type="date" value={txForm.date} onChange={(e) => setTxForm({ ...txForm, date: e.target.value })} className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm" />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{tr('طريقة الدفع', 'Payment')}</label>
                <select value={txForm.paymentMethod} onChange={(e) => setTxForm({ ...txForm, paymentMethod: e.target.value })} className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm bg-white">
                  <option>تحويل بنكي</option>
                  <option>نقدي / شبكة</option>
                  <option>آجل (ذمم)</option>
                </select>
              </div>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">{tr('الكمية (اختياري)', 'Quantity (optional)')}</label>
              <input type="text" value={txForm.quantityLabel} onChange={(e) => setTxForm({ ...txForm, quantityLabel: e.target.value })} className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm" />
            </div>

            <button type="submit" className="w-full py-2.5 rounded-xl bg-[#14532D] text-white text-sm font-bold">
              {tr('حفظ القيد', 'Save')}
            </button>
          </form>
        </Modal>
      )}

      {/* Add pivot modal */}
      {quickModal === 'addPivot' && (
        <Modal onClose={() => setQuickModal(null)} title={tr('إضافة رشاش', 'Add pivot')}>
          <PivotForm mode="add" tr={tr} onSubmit={handleAddPivot} />
        </Modal>
      )}

      {/* Edit pivot modal */}
      {editPivotId && pivots.some((x) => x.id === editPivotId) && (
        <Modal onClose={() => setEditPivotId(null)} title={tr('تعديل بيانات الرشاش', 'Edit pivot')}>
          <PivotForm key={editPivotId} mode="edit" initial={pivots.find((x) => x.id === editPivotId)} tr={tr} onSubmit={handleEditPivot} />
        </Modal>
      )}

      {/* Add greenhouse modal */}
      {quickModal === 'addGh' && (
        <Modal onClose={() => setQuickModal(null)} title={tr('بيت محمي جديد', 'New greenhouse')}>
          <form onSubmit={handleAddGreenhouse} className="space-y-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">{tr('الاسم', 'Name')}</label>
              <input value={ghForm.name} onChange={(e) => setGhForm({ ...ghForm, name: e.target.value })} className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm" />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">{tr('المحصول', 'Crop')}</label>
              <input value={ghForm.crop} onChange={(e) => setGhForm({ ...ghForm, crop: e.target.value })} className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm" />
            </div>
            <p className="text-xs text-slate-500">{tr('صالة أولى — تقدر تضيف صالات أخرى بعد الحفظ', 'First hall — add more halls after saving')}</p>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{tr('عدد الخطوط', 'Rows')}</label>
                <input type="number" min="1" value={ghForm.rows} onChange={(e) => setGhForm({ ...ghForm, rows: e.target.value })} className="w-full px-3 py-2 rounded-xl border border-emerald-400 text-sm font-extrabold tabular-nums" />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{tr('شتلة/خط', 'Plants/row')}</label>
                <input type="number" min="1" value={ghForm.plantsPerRow} onChange={(e) => setGhForm({ ...ghForm, plantsPerRow: e.target.value })} className="w-full px-3 py-2 rounded-xl border border-emerald-400 text-sm font-extrabold tabular-nums" />
              </div>
            </div>
            <div className="p-3 rounded-xl bg-sky-50 border border-sky-200 text-xs font-bold text-sky-900">
              = {formatNumber((Number(ghForm.rows) || 0) * (Number(ghForm.plantsPerRow) || 0), lang)} {tr('شتلة', 'plants')}
            </div>
            <button type="submit" className="w-full py-2.5 rounded-xl bg-[#14532D] text-white text-sm font-bold">
              {tr('حفظ البيت المحمي', 'Save greenhouse')}
            </button>
          </form>
        </Modal>
      )}

      {/* Add orchard modal */}
      {quickModal === 'addOrc' && (
        <Modal onClose={() => setQuickModal(null)} title={tr('بستان جديد', 'New orchard')}>
          <form onSubmit={handleAddOrchard} className="space-y-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">{tr('الاسم', 'Name')}</label>
              <input value={orcForm.name} onChange={(e) => setOrcForm({ ...orcForm, name: e.target.value })} className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm" />
            </div>
            <p className="text-xs text-slate-500">{tr('صنف أول — تقدر تضيف أصناف أخرى بعد الحفظ', 'First variety — add more after saving')}</p>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{tr('نوع الشجر', 'Tree type')}</label>
                <input value={orcForm.treeType} onChange={(e) => setOrcForm({ ...orcForm, treeType: e.target.value })} placeholder={tr('نخيل، حمضيات...', 'Palms, citrus...')} className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm" />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{tr('عدد الأشجار', 'Tree count')}</label>
                <input type="number" min="1" value={orcForm.treeCount} onChange={(e) => setOrcForm({ ...orcForm, treeCount: e.target.value })} className="w-full px-3 py-2 rounded-xl border border-amber-400 text-sm font-extrabold tabular-nums" />
              </div>
            </div>
            <button type="submit" className="w-full py-2.5 rounded-xl bg-[#14532D] text-white text-sm font-bold">
              {tr('حفظ البستان', 'Save orchard')}
            </button>
          </form>
        </Modal>
      )}

      {/* Onboarding */}
      {showOnboarding && (
        <Modal hideClose title={tr('مرحباً بك في أجري', 'Welcome to AGRI')}>
          <div className="space-y-4">
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{tr('الاسم', 'Name')}</label>
                <input value={obName} onChange={(e) => setObName(e.target.value)} autoComplete="name" className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm" />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">{tr('رقم الجوال', 'Mobile number')}</label>
                <input value={obPhone} onChange={(e) => setObPhone(e.target.value)} type="tel" inputMode="tel" autoComplete="tel" placeholder="05xxxxxxxx" dir="ltr" className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm font-mono" />
                {obPhone && !isValidPhone(obPhone) && <p className="text-[11px] text-rose-600 mt-1">{tr('أدخل رقم جوال سعودي صحيح يبدأ بـ 05', 'Enter a valid Saudi mobile starting with 05')}</p>}
              </div>
            </div>
            <p className="text-sm text-slate-600">{tr('اختر الأنواع التي تعمل بها في مزرعتك. كل نوع له حساباته الخاصة.', 'Pick the types your farm works with. Each has its own calculations.')}</p>
            <div className="space-y-2">
              {UNIT_TYPES.map((ut) => {
                const Icon = ut.icon;
                const checked = obTypes.includes(ut.id);
                return (
                  <label key={ut.id} className={`flex items-center justify-between p-3 rounded-xl border ${checked ? 'border-emerald-500 bg-emerald-50' : 'border-slate-200'}`}>
                    <span className="flex items-center gap-2.5 text-sm font-bold text-slate-800">
                      <Icon className="w-4.5 h-4.5" /> {tr(ut.label, ut.labelEn)}
                    </span>
                    <input
                      type="checkbox"
                      checked={checked}
                      onChange={(e) => setObTypes(e.target.checked ? [...obTypes, ut.id] : obTypes.filter((x) => x !== ut.id))}
                      className="w-5 h-5"
                    />
                  </label>
                );
              })}
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">{tr('اسم المزرعة (اختياري)', 'Farm name (optional)')}</label>
              <input value={obFarmName} onChange={(e) => setObFarmName(e.target.value)} className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm" />
            </div>
            <p className="text-[11px] text-slate-500">{tr('سنستخدم اسمك ورقمك للتواصل معك بخصوص التطبيق فقط.', 'We only use your name and number to contact you about the app.')}</p>
            <button disabled={!obValid} onClick={completeOnboarding} className="w-full py-2.5 rounded-xl bg-[#14532D] disabled:opacity-40 text-white text-sm font-bold flex items-center justify-center gap-1.5">
              <Sparkles className="w-4 h-4" /> {tr('بدء الاستخدام', 'Start')}
            </button>
          </div>
        </Modal>
      )}
    </div>
  );
}

function Modal({ onClose, title, children, hideClose }) {
  return (
    <div className="fixed inset-0 bg-slate-950/60 z-50 flex items-end sm:items-center justify-center">
      <div className="bg-white rounded-t-3xl sm:rounded-3xl w-full max-w-md max-h-[92vh] overflow-y-auto p-5">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
          <h3 className="text-base font-extrabold text-slate-900">{title}</h3>
          {!hideClose && (
            <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-500">
              <X className="w-5 h-5" />
            </button>
          )}
        </div>
        {children}
      </div>
    </div>
  );
}

function Ledger({ txList, tr, num, money, onDelete, onSettle }) {
  const pending = (t) => (t.type === 'revenue' && t.status === 'مستحق للتحصيل') || (t.type === 'expense' && String(t.status).startsWith('ذمم'));
  return (
    <div className="space-y-2">
      <h4 className="text-sm font-extrabold text-slate-900">{tr('سجل القيود', 'Ledger')}</h4>
      {[...txList]
        .sort((a, b) => b.date.localeCompare(a.date))
        .map((t) => (
          <div key={t.id} className="bg-white rounded-xl p-3 border border-slate-200 space-y-1.5">
            <div className="flex items-start justify-between gap-2">
              <div>
                <p className="text-sm font-bold text-slate-900">{t.title}</p>
                <p className="text-[11px] text-slate-500">{t.date} • {t.category}</p>
              </div>
              <div className="flex items-center gap-1 shrink-0">
                <span className={`text-sm font-extrabold tabular-nums ${t.type === 'revenue' ? 'text-emerald-700' : 'text-rose-700'}`}>
                  {t.type === 'revenue' ? '+' : '-'}{money(t.amount)}
                </span>
                <button onClick={() => onDelete(t.id)} className="p-1 text-slate-400 hover:text-rose-600">
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
            {t.quantityLabel && <p className="text-[11px] text-slate-500">{t.quantityLabel}</p>}
            {pending(t) && (
              <div className="flex items-center justify-between">
                <span className={`text-[11px] font-bold px-2 py-0.5 rounded ${t.type === 'revenue' ? 'bg-sky-100 text-sky-900' : 'bg-amber-100 text-amber-900'}`}>{t.status}</span>
                <button onClick={() => onSettle(t.id)} className="text-[11px] font-bold text-emerald-700 underline">
                  {t.type === 'revenue' ? tr('تم التحصيل', 'Collected') : tr('تم السداد', 'Paid')}
                </button>
              </div>
            )}
          </div>
        ))}
      {txList.length === 0 && <p className="text-center text-xs text-slate-400 py-6">{tr('لا توجد قيود بعد', 'No entries yet')}</p>}
    </div>
  );
}
