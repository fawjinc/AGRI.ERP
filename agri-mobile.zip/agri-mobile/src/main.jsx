import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.jsx';
import './index.css';

// تطبيق الوضع الداكن المحفوظ قبل أول رسم لتجنّب "الوميض" بين الفاتح والداكن
try {
  const saved = localStorage.getItem('agri-theme');
  const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
  const theme = saved || (prefersDark ? 'dark' : 'light');
  document.documentElement.classList.toggle('dark', theme === 'dark');
} catch {
  // متصفحات بدون localStorage (نادر) — نتجاهل ونكمل بالوضع الفاتح
}

createRoot(document.getElementById('root')).render(<App />);
