// ==========================================
// التقرير المحاسبي (Excel) — أربع أوراق: الملخص، سجل القيود، المصروفات حسب البند، تكلفة الإنتاج
// يُبنى من نفس بيانات التطبيق، ويُكتب كملف xlsx حقيقي بدون أي مكتبة خارجية
// ==========================================

const TOWER_LENGTH = 50;
const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const sum = (arr, f) => arr.reduce((a, x) => a + (Number(f(x)) || 0), 0);
const tonsFromCount = (count, weightKg) => r2(((Number(count) || 0) * (Number(weightKg) || 0)) / 1000);

// نفس قاعدة التطبيق: الإنتاج يتبع العدد × الوزن تلقائياً إلا لو كُتب يدوياً
const effectiveTons = (u, countKey, weightKey) =>
  u.productionMode !== 'manual' && Number(u[countKey]) > 0 ? tonsFromCount(u[countKey], u[weightKey]) : Number(u.productionTons) || 0;

const pivotArea = (p) => {
  const radius = (Number(p.towers) || 0) * TOWER_LENGTH + (p.hasExtension ? Number(p.extensionLength) || 0 : 0);
  const angle = Math.min(360, Math.max(1, Number(p.operatingAngle) || 360));
  return r2((Math.PI * radius * radius * (angle / 360)) / 10000);
};

export function buildAccountingReport(state, period) {
  const { farms = [], pivots = [], greenhouses = [], orchards = [], leafies = [], transactions = [] } = state;
  const farmName = (id) => (farms.find((f) => f.id === id) || {}).name || '';
  const plantCount = (g) => (g.halls || []).reduce((s, h) => s + (Number(h.rows) || 0) * (Number(h.plantsPerRow) || 0), 0);
  const treeCount = (o) => (o.varieties || []).reduce((s, v) => s + (Number(v.treeCount) || 0), 0);
  const areaOf = (p) => Number(p.actualMeasuredArea) || pivotArea(p);

  const units = [
    ...pivots.map((u) => {
      const forage = u.cropCategory === 'forage';
      return {
        id: u.id, type: 'pivot', farmId: u.farmId, kind: 'رشاش محوري', name: u.name, crop: u.currentCrop || '',
        size: `${areaOf(u)} هكتار`, sizeNum: areaOf(u), sizeUnit: 'هكتار',
        prod: { unit: forage ? 'لبنة' : 'كيس', weight: Number(u.baleWeightKg) || 0, price: Number(u.marketPricePerUnit) || 0, priceUnit: forage ? 'unit' : 'ton', tons: effectiveTons(u, 'bagsCount', 'baleWeightKg') }
      };
    }),
    ...leafies.map((u) => ({
      id: u.id, type: 'leafy', farmId: u.farmId, kind: 'رشاش ورقيات', name: u.name, crop: u.currentCrop || '',
      size: `${areaOf(u)} هكتار`, sizeNum: areaOf(u), sizeUnit: 'هكتار',
      prod: { unit: 'كرتونة', weight: Number(u.boxWeightKg) || 0, price: Number(u.sellingPricePerBox) || 0, priceUnit: 'unit', tons: effectiveTons(u, 'boxesCount', 'boxWeightKg') }
    })),
    ...greenhouses.map((u) => ({
      id: u.id, type: 'greenhouse', farmId: u.farmId, kind: 'بيت محمي', name: u.name, crop: u.crop || '',
      size: `${plantCount(u)} شتلة`, sizeNum: plantCount(u), sizeUnit: 'شتلة',
      prod: { unit: 'فلينة', weight: Number(u.boxWeightKg) || 0, price: Number(u.sellingPricePerBox) || 0, priceUnit: 'unit', tons: effectiveTons(u, 'boxesCount', 'boxWeightKg') }
    })),
    ...orchards.map((u) => ({
      id: u.id, type: 'orchard', farmId: u.farmId, kind: 'بستان', name: u.name, crop: (u.varieties || []).map((v) => v.treeType).filter(Boolean).join('، '),
      size: `${treeCount(u)} شجرة`, sizeNum: treeCount(u), sizeUnit: 'شجرة',
      prod: { unit: 'صندوق', weight: Number(u.boxWeightKg) || 0, price: Number(u.sellingPricePerBox) || 0, priceUnit: 'unit', tons: effectiveTons(u, 'boxesCount', 'boxWeightKg') }
    }))
  ];
  const byId = Object.fromEntries(units.map((u) => [u.id, u]));
  const tx = transactions
    .filter((t) => (!period?.from || t.date >= period.from) && (!period?.to || t.date <= period.to))
    .slice()
    .sort((a, b) => String(a.date).localeCompare(String(b.date)));
  const isInc = (t) => t.type === 'revenue' || t.type === 'income';
  const isExp = (t) => t.type === 'expense';
  const general = tx.filter((t) => !t.unitId || !byId[t.unitId]);

  // 1) الملخص
  const summary = [['المزرعة', 'نوع الوحدة', 'الوحدة', 'المحصول', 'المساحة / العدد', 'الإيرادات', 'المصروفات', 'صافي الربح', 'هامش الربح %', 'التكلفة لكل']];
  let TI = 0, TE = 0;
  units.forEach((u) => {
    const t = tx.filter((x) => x.unitId === u.id);
    const inc = sum(t.filter(isInc), (x) => x.amount), exp = sum(t.filter(isExp), (x) => x.amount);
    TI += inc; TE += exp;
    summary.push([farmName(u.farmId), u.kind, u.name, u.crop, u.size, inc, exp, inc - exp, inc ? r2(((inc - exp) / inc) * 100) : 0, u.sizeNum ? `${r2(exp / u.sizeNum)} ر.س / ${u.sizeUnit}` : '']);
  });
  if (general.length) {
    const inc = sum(general.filter(isInc), (x) => x.amount), exp = sum(general.filter(isExp), (x) => x.amount);
    TI += inc; TE += exp;
    summary.push(['', 'عام', 'بدون وحدة', '', '', inc, exp, inc - exp, inc ? r2(((inc - exp) / inc) * 100) : 0, '']);
  }
  summary.push(['الإجمالي', '', '', '', '', TI, TE, TI - TE, TI ? r2(((TI - TE) / TI) * 100) : 0, '']);

  // 2) سجل القيود
  const ledger = [['التاريخ', 'المزرعة', 'نوع الوحدة', 'الوحدة', 'التصنيف', 'البيان', 'الكمية', 'الحالة', 'إيراد', 'مصروف']];
  tx.forEach((t) => {
    const u = byId[t.unitId];
    ledger.push([t.date, farmName(t.farmId || u?.farmId), u ? u.kind : 'عام', u ? u.name : '', t.category || '', t.title || t.note || '', t.quantityLabel || '', t.status || '', isInc(t) ? Number(t.amount) || 0 : '', isExp(t) ? Number(t.amount) || 0 : '']);
  });
  ledger.push(['الإجمالي', '', '', '', '', '', '', '', TI, TE]);

  // 3) المصروفات حسب البند
  const cols = [...units, ...(general.some(isExp) ? [{ id: '__general', name: 'عام' }] : [])];
  const inCol = (t, c) => (c.id === '__general' ? !t.unitId || !byId[t.unitId] : t.unitId === c.id);
  const exps = tx.filter(isExp);
  const cats = [...new Set(exps.map((t) => t.category || 'بدون تصنيف'))];
  const byCat = [['البند', ...cols.map((c) => c.name), 'الإجمالي', 'النسبة %']];
  cats.forEach((cat) => {
    const row = cols.map((c) => sum(exps.filter((t) => (t.category || 'بدون تصنيف') === cat && inCol(t, c)), (t) => t.amount));
    const tot = sum(row, (x) => x);
    byCat.push([cat, ...row, tot, TE ? r2((tot / TE) * 100) : 0]);
  });
  byCat.push(['الإجمالي', ...cols.map((c) => sum(exps.filter((t) => inCol(t, c)), (t) => t.amount)), TE, TE ? 100 : 0]);

  // 4) تكلفة الإنتاج (نفس حساب كارت "تكلفة وحدة الإنتاج")
  const prod = [['الوحدة', 'نوع الوحدة', 'المحصول', 'وحدة البيع', 'العدد', 'الوزن (كجم)', 'الإنتاج (طن)', 'المصروفات', 'تكلفة الطن', 'تكلفة الوحدة', 'الإيراد المتوقع', 'الربح المتوقع']];
  units.forEach((u) => {
    const p = u.prod;
    if (!(p.tons > 0)) return;
    const exp = sum(tx.filter((t) => isExp(t) && t.unitId === u.id), (t) => t.amount);
    const count = p.weight > 0 ? r2((p.tons * 1000) / p.weight) : 0;
    const rev = p.priceUnit === 'ton' ? p.tons * p.price : count * p.price;
    prod.push([u.name, u.kind, u.crop, p.unit, count, p.weight, p.tons, exp, r2(exp / p.tons), count ? r2(exp / count) : 0, r2(rev), r2(rev - exp)]);
  });

  return {
    title: 'التقرير المحاسبي',
    period: period ? `${period.from || 'البداية'} إلى ${period.to || 'اليوم'}` : 'كل الفترات',
    sheets: [
      { name: 'الملخص', rows: summary, totalLast: true },
      { name: 'سجل القيود', rows: ledger, totalLast: true },
      { name: 'المصروفات حسب البند', rows: byCat, totalLast: true },
      { name: 'تكلفة الإنتاج', rows: prod, totalLast: false }
    ]
  };
}

// ---------- كاتب xlsx بسيط (zip بدون ضغط) ----------
const CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c >>> 0;
  }
  return t;
})();
const crc32 = (bytes) => {
  let c = 0xffffffff;
  for (let i = 0; i < bytes.length; i++) c = CRC_TABLE[(c ^ bytes[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
};

function zipStore(files) {
  const enc = new TextEncoder();
  const parts = [], central = [];
  let offset = 0;
  files.forEach(({ name, data }) => {
    const nameB = enc.encode(name), dataB = typeof data === 'string' ? enc.encode(data) : data;
    const crc = crc32(dataB);
    const local = new DataView(new ArrayBuffer(30));
    local.setUint32(0, 0x04034b50, true); local.setUint16(4, 20, true); local.setUint16(6, 0x0800, true);
    local.setUint32(14, crc, true); local.setUint32(18, dataB.length, true); local.setUint32(22, dataB.length, true);
    local.setUint16(26, nameB.length, true);
    parts.push(new Uint8Array(local.buffer), nameB, dataB);
    const cen = new DataView(new ArrayBuffer(46));
    cen.setUint32(0, 0x02014b50, true); cen.setUint16(4, 20, true); cen.setUint16(6, 20, true); cen.setUint16(8, 0x0800, true);
    cen.setUint32(16, crc, true); cen.setUint32(20, dataB.length, true); cen.setUint32(24, dataB.length, true);
    cen.setUint16(28, nameB.length, true); cen.setUint32(42, offset, true);
    central.push(new Uint8Array(cen.buffer), nameB);
    offset += 30 + nameB.length + dataB.length;
  });
  const cenSize = central.reduce((a, b) => a + b.length, 0);
  const end = new DataView(new ArrayBuffer(22));
  end.setUint32(0, 0x06054b50, true); end.setUint16(8, files.length, true); end.setUint16(10, files.length, true);
  end.setUint32(12, cenSize, true); end.setUint32(16, offset, true);
  return new Blob([...parts, ...central, new Uint8Array(end.buffer)], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
}

const xmlEsc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, '');
const colName = (i) => { let s = ''; i++; while (i > 0) { const m = (i - 1) % 26; s = String.fromCharCode(65 + m) + s; i = Math.floor((i - 1) / 26); } return s; };

function sheetXml(rows, totalLast) {
  const widths = (rows[0] || []).map((_, c) => Math.min(40, Math.max(10, ...rows.map((r) => String(r[c] ?? '').length + 2))));
  const body = rows.map((r, ri) => {
    const isHead = ri === 0, isTot = totalLast && ri === rows.length - 1 && ri > 0;
    const cells = r.map((v, ci) => {
      const ref = `${colName(ci)}${ri + 1}`;
      if (v === '' || v === null || v === undefined) return isHead || isTot ? `<c r="${ref}" s="${isHead ? 1 : 2}"/>` : '';
      if (typeof v === 'number' && isFinite(v)) return `<c r="${ref}" s="${isHead ? 1 : isTot ? 3 : 4}"><v>${v}</v></c>`;
      return `<c r="${ref}" t="inlineStr" s="${isHead ? 1 : isTot ? 2 : 0}"><is><t>${xmlEsc(v)}</t></is></c>`;
    }).join('');
    return `<row r="${ri + 1}">${cells}</row>`;
  }).join('');
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView rightToLeft="1" workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><cols>${widths.map((w, i) => `<col min="${i + 1}" max="${i + 1}" width="${w}" customWidth="1"/>`).join('')}</cols><sheetData>${body}</sheetData></worksheet>`;
}

export function reportToXlsx(report) {
  const sheets = report.sheets;
  const styles = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><numFmts count="1"><numFmt numFmtId="164" formatCode="#,##0.##"/></numFmts><fonts count="3"><font><sz val="11"/><name val="Arial"/></font><font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Arial"/></font><font><b/><sz val="11"/><name val="Arial"/></font></fonts><fills count="4"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF1A5632"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFE9F8EF"/></patternFill></fill></fills><borders count="1"><border/></borders><cellStyleXfs count="1"><xf/></cellStyleXfs><cellXfs count="5"><xf/><xf fontId="1" fillId="2" applyFont="1" applyFill="1"/><xf fontId="2" fillId="3" applyFont="1" applyFill="1"/><xf fontId="2" fillId="3" numFmtId="164" applyFont="1" applyFill="1" applyNumberFormat="1"/><xf numFmtId="164" applyNumberFormat="1"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>`;
  const files = [
    { name: '[Content_Types].xml', data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>${sheets.map((_, i) => `<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join('')}</Types>` },
    { name: '_rels/.rels', data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>` },
    { name: 'xl/workbook.xml', data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><bookViews><workbookView/></bookViews><sheets>${sheets.map((s, i) => `<sheet name="${xmlEsc(s.name.slice(0, 31))}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`).join('')}</sheets></workbook>` },
    { name: 'xl/_rels/workbook.xml.rels', data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${sheets.map((_, i) => `<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i + 1}.xml"/>`).join('')}<Relationship Id="rId${sheets.length + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>` },
    { name: 'xl/styles.xml', data: styles },
    ...sheets.map((s, i) => ({ name: `xl/worksheets/sheet${i + 1}.xml`, data: sheetXml(s.rows, s.totalLast) }))
  ];
  return zipStore(files);
}
