// ==========================================
// AgriWhatsAppLogin — دخول أجري ERP المجاني بواتساب
// العميل يكتب رقمه ← نعطيه كود AGRI-xxxxxx ← يرسله من واتسابه لرقم كيان ← يدخل تلقائياً.
// Backend: Cloudflare Worker agri-auth (مجرّب وشغّال)
//   POST /auth/wa-start {phone}           -> {ok, code, nonce, waNumber, text, expiresIn}
//   POST /auth/wa-poll  {code, nonce}     -> {ok, pending:true} | {ok, token, user, needsName, isNew}
//                                             | {ok:false, expired|mismatch, error}
//   POST /auth/me/name  {name} + Authorization: Bearer <token> -> {ok, user}
// React + Tailwind، بدون مكتبات إضافية. اتجاه RTL.
// ==========================================
import React, { useCallback, useEffect, useRef, useState } from 'react';

export const AUTH_API = 'https://agri-auth.fawj-inc.workers.dev';
const SESSION_KEY = 'agri_auth_session'; // { token, user: { phone, name } }
const PENDING_KEY = 'agri_auth_pending'; // { code, nonce, phone, waNumber, text, exp }
const POLL_MS = 2500;

// ---------- أدوات الجلسة (استخدمها في باقي التطبيق) ----------
const store = {
  get(k) { try { return JSON.parse(localStorage.getItem(k) || 'null'); } catch { return null; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} },
  del(k) { try { localStorage.removeItem(k); } catch {} }
};
export const getSession = () => store.get(SESSION_KEY);
export const logout = () => { store.del(SESSION_KEY); store.del(PENDING_KEY); };

// 05xxxxxxxx / 5xxxxxxxx / +9665… / 009665… -> 9665xxxxxxxx ، و 01xxxxxxxxx (مصر) -> 201xxxxxxxxx
export function normalizePhone(input) {
  let d = String(input || '').replace(/[٠-٩]/g, (c) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(c))).replace(/\D/g, '');
  if (d.startsWith('00')) d = d.slice(2);
  if (/^05\d{8}$/.test(d)) return '966' + d.slice(1);
  if (/^5\d{8}$/.test(d)) return '966' + d;
  if (/^01[0125]\d{8}$/.test(d)) return '20' + d.slice(1);
  return d;
}
const validPhone = (p) => /^(9665\d{8}|20(10|11|12|15)\d{8}|9715\d{8})$/.test(p);

async function api(path, body, token) {
  const r = await fetch(AUTH_API + path, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    body: JSON.stringify(body)
  });
  const data = await r.json().catch(() => ({ ok: false, error: 'تعذر الاتصال. حاول مرة ثانية.' }));
  return data;
}

// في نسخة الجوال (Capacitor) يفتح تطبيق واتساب نفسه، وفي الويب تبويب جديد
function openWhatsApp(url) {
  const isNative = typeof window !== 'undefined' && window.Capacitor && typeof window.Capacitor.isNativePlatform === 'function' && window.Capacitor.isNativePlatform();
  window.open(url, isNative ? '_system' : '_blank', isNative ? undefined : 'noopener,noreferrer');
}

// ---------- المكوّن ----------
// onLogin({ token, user }) يُستدعى بعد الدخول (وبعد كتابة الاسم لو كان جديد).
export default function AgriWhatsAppLogin({ onLogin }) {
  const [step, setStep] = useState('phone'); // phone | send | name
  const [phone, setPhone] = useState('');
  const [pending, setPending] = useState(null);
  const [name, setName] = useState('');
  const [session, setSession] = useState(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [left, setLeft] = useState(0);
  const [copied, setCopied] = useState(false);
  const pollRef = useRef(null);
  const inFlight = useRef(false);

  const finish = useCallback((s) => {
    store.set(SESSION_KEY, s);
    store.del(PENDING_KEY);
    onLogin && onLogin(s);
  }, [onLogin]);

  const stopPolling = () => { if (pollRef.current) clearInterval(pollRef.current); pollRef.current = null; };

  const pollOnce = useCallback(async (p) => {
    if (!p || inFlight.current) return;
    if (Date.now() > p.exp) { stopPolling(); store.del(PENDING_KEY); setError('انتهت مهلة الكود. اطلب كود جديد.'); setStep('phone'); return; }
    inFlight.current = true;
    try {
      const r = await api('/auth/wa-poll', { code: p.code, nonce: p.nonce });
      if (r.ok && r.pending) return;
      stopPolling();
      if (r.ok && r.token) {
        const s = { token: r.token, user: r.user };
        if (r.needsName) { setSession(s); store.del(PENDING_KEY); setStep('name'); }
        else finish(s);
        return;
      }
      store.del(PENDING_KEY);
      setError(r.error || 'حصل خطأ. حاول مرة ثانية.');
      setStep('phone');
    } catch {
      // خطأ شبكة مؤقت: نكمل المحاولة في الدورة الجاية
    } finally {
      inFlight.current = false;
    }
  }, [finish]);

  const startPolling = useCallback((p) => {
    stopPolling();
    pollOnce(p);
    pollRef.current = setInterval(() => pollOnce(p), POLL_MS);
  }, [pollOnce]);

  // لو التطبيق انقفل/انعاد تحميله وهو رايح لواتساب: نكمل من نفس الكود
  useEffect(() => {
    const p = store.get(PENDING_KEY);
    if (p && Date.now() < p.exp) { setPending(p); setPhone(p.phone); setStep('send'); startPolling(p); }
    else store.del(PENDING_KEY);
    return stopPolling;
  }, [startPolling]);

  // أول ما يرجع من واتساب للتطبيق: نتحقق فوراً بدل ما ننتظر الدورة
  useEffect(() => {
    const onBack = () => { if (document.visibilityState === 'visible' && pending) pollOnce(pending); };
    document.addEventListener('visibilitychange', onBack);
    window.addEventListener('focus', onBack);
    return () => { document.removeEventListener('visibilitychange', onBack); window.removeEventListener('focus', onBack); };
  }, [pending, pollOnce]);

  // عدّاد الوقت المتبقي
  useEffect(() => {
    if (step !== 'send' || !pending) return;
    const t = setInterval(() => setLeft(Math.max(0, Math.ceil((pending.exp - Date.now()) / 1000))), 1000);
    setLeft(Math.max(0, Math.ceil((pending.exp - Date.now()) / 1000)));
    return () => clearInterval(t);
  }, [step, pending]);

  async function requestCode(e) {
    e && e.preventDefault();
    setError('');
    const p = normalizePhone(phone);
    if (!validPhone(p)) { setError('اكتب رقم جوال صحيح، مثل 05XXXXXXXX'); return; }
    setBusy(true);
    try {
      const r = await api('/auth/wa-start', { phone: p });
      if (!r.ok) { setError(r.error || 'حصل خطأ. حاول مرة ثانية.'); return; }
      const pend = { code: r.code, nonce: r.nonce, phone: p, waNumber: r.waNumber, text: r.text, exp: Date.now() + (r.expiresIn || 600000) };
      store.set(PENDING_KEY, pend);
      setPending(pend);
      setStep('send');
      startPolling(pend);
    } catch {
      setError('تعذر الاتصال. تأكد من الإنترنت وحاول مرة ثانية.');
    } finally {
      setBusy(false);
    }
  }

  async function saveName(e) {
    e && e.preventDefault();
    setError('');
    const n = name.trim();
    if (n.length < 2) { setError('اكتب اسمك عشان تكمل.'); return; }
    setBusy(true);
    try {
      const r = await api('/auth/me/name', { name: n }, session.token);
      if (!r.ok) { setError(r.error || 'حصل خطأ. حاول مرة ثانية.'); if (r.error && /دخول/.test(r.error)) { logout(); setStep('phone'); } return; }
      finish({ token: session.token, user: r.user });
    } catch {
      setError('تعذر الاتصال. حاول مرة ثانية.');
    } finally {
      setBusy(false);
    }
  }

  function cancel() { stopPolling(); store.del(PENDING_KEY); setPending(null); setError(''); setStep('phone'); }

  async function copyCode() {
    try { await navigator.clipboard.writeText(pending.text); setCopied(true); setTimeout(() => setCopied(false), 1500); } catch {}
  }

  const waLink = pending ? `https://wa.me/${pending.waNumber}?text=${encodeURIComponent(pending.text)}` : '#';
  const prettyBiz = pending ? '0' + String(pending.waNumber).replace(/^966/, '') : '';
  const mm = String(Math.floor(left / 60)).padStart(2, '0');
  const ss = String(left % 60).padStart(2, '0');

  return (
    <div dir="rtl" className="w-full max-w-sm mx-auto p-6 bg-white rounded-2xl shadow-sm border border-gray-100 text-gray-800">
      <div className="text-center mb-5">
        <div className="text-2xl font-bold text-green-800">أجري ERP</div>
        <div className="text-sm text-gray-500 mt-1">
          {step === 'phone' && 'سجّل دخولك برقم جوالك عن طريق واتساب'}
          {step === 'send' && 'أرسل الكود من واتسابك وندخلك تلقائياً'}
          {step === 'name' && 'أهلاً بك! اكتب اسمك'}
        </div>
      </div>

      {step === 'phone' && (
        <form onSubmit={requestCode} className="space-y-3">
          <label className="block text-sm font-medium">رقم الجوال (عليه واتساب)</label>
          <input
            type="tel" inputMode="tel" autoComplete="tel" dir="ltr" placeholder="05XXXXXXXX"
            value={phone} onChange={(e) => setPhone(e.target.value)}
            className="w-full rounded-xl border border-gray-300 px-4 py-3 text-lg text-left tracking-wider focus:outline-none focus:ring-2 focus:ring-green-600"
          />
          <button type="submit" disabled={busy}
            className="w-full rounded-xl bg-green-700 hover:bg-green-800 disabled:opacity-60 text-white font-bold py-3">
            {busy ? 'لحظة…' : 'دخول بواتساب'}
          </button>
        </form>
      )}

      {step === 'send' && pending && (
        <div className="space-y-4 text-center">
          <div className="text-sm text-gray-600">
            من واتساب الرقم <span dir="ltr" className="font-semibold">0{String(pending.phone).replace(/^966/, '')}</span> أرسل هذا الكود إلى <span dir="ltr" className="font-semibold">{prettyBiz}</span>
          </div>
          <button type="button" onClick={copyCode}
            className="w-full rounded-xl bg-gray-50 border border-dashed border-green-700 py-4 text-3xl font-bold tracking-widest text-green-800" dir="ltr">
            {pending.code}
          </button>
          <div className="text-xs text-gray-400">{copied ? 'تم النسخ' : 'اضغط على الكود لنسخه'}</div>
          <button type="button" onClick={() => openWhatsApp(waLink)}
            className="block w-full rounded-xl bg-[#25D366] hover:bg-[#1ebe5b] text-white font-bold py-3">
            افتح واتساب وأرسل الكود
          </button>
          <div className="flex items-center justify-center gap-2 text-sm text-gray-500">
            <span className="inline-block h-3 w-3 rounded-full border-2 border-green-700 border-t-transparent animate-spin" />
            ننتظر رسالتك… <span dir="ltr">{mm}:{ss}</span>
          </div>
          <button type="button" onClick={cancel} className="text-sm text-gray-500 underline">تغيير الرقم</button>
        </div>
      )}

      {step === 'name' && (
        <form onSubmit={saveName} className="space-y-3">
          <label className="block text-sm font-medium">الاسم</label>
          <input
            type="text" autoComplete="name" placeholder="مثال: محمد أحمد" maxLength={60}
            value={name} onChange={(e) => setName(e.target.value)}
            className="w-full rounded-xl border border-gray-300 px-4 py-3 text-lg focus:outline-none focus:ring-2 focus:ring-green-600"
          />
          <button type="submit" disabled={busy}
            className="w-full rounded-xl bg-green-700 hover:bg-green-800 disabled:opacity-60 text-white font-bold py-3">
            {busy ? 'لحظة…' : 'متابعة'}
          </button>
        </form>
      )}

      {error && <div className="mt-4 rounded-xl bg-red-50 text-red-700 text-sm p-3 text-center">{error}</div>}
    </div>
  );
}
