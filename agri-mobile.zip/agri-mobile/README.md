# أجري ERP — تطبيق أندرويد عبر Capacitor

هذا مشروع **Vite + React + Tailwind + Capacitor** جاهز لتحويل تطبيق "أجري ERP" (المزارع ← رشاشات/بيوت محمية/بساتين)
إلى تطبيق أندرويد حقيقي (APK). الكود نفسه في `src/App.jsx` هو تطبيقك دون أي تغيير جوهري في المنطق —
فقط أضفنا:

- زر **وضع داكن/فاتح** في الهيدر وفي الإعدادات (يُحفظ في `localStorage` ويتبع إعداد الجهاز تلقائياً أول مرة).
- طبقة CSS صغيرة في `src/index.css` تجعل الوضع الداكن يعمل مع كلاسات Tailwind الموجودة.
- هيكلة Capacitor القياسية (`capacitor.config.ts`) لتغليف التطبيق كـ WebView أندرويد.

**التخزين المحلي (localStorage) والتصميم المتجاوب للموبايل موجودان بالفعل في الكود الأصلي** —
Capacitor يستخدم WebView حقيقي، و`localStorage` يعمل فيه تماماً كما في المتصفح، والبيانات تبقى
محفوظة داخل التطبيق (sandbox خاص بالتطبيق) حتى بعد إغلاقه أو إعادة تشغيل الجهاز.

> ⚠️ **ملاحظة مهمة**: لا يوجد لدي اتصال إنترنت في هذه البيئة لتشغيل `npm install` أو لبناء APK فعلياً
> وتجربته. كل الملفات هنا صحيحة بنيوياً وتتبع الطريقة القياسية الموثّقة لـ Capacitor، وتم فحص
> كود React نفسه (`src/App.jsx`) بأداة بناء (esbuild) وبتصيير فعلي للتأكد من خلوه من الأخطاء —
> لكن خطوات `npm install` و Gradle **يجب أن تُنفَّذ على جهازك** (أو على GitHub Actions) حيث يوجد اتصال فعلي.

---

## 1) بنية المشروع

```
agri-mobile/
├── index.html
├── package.json
├── vite.config.js
├── tailwind.config.js
├── postcss.config.js
├── capacitor.config.ts
├── src/
│   ├── main.jsx       ← نقطة الدخول، تطبّق الوضع الداكن المحفوظ قبل أول رسم
│   ├── App.jsx         ← تطبيقك الكامل (نفس المنطق + زر الوضع الداكن)
│   └── index.css       ← Tailwind + طبقة توافق الوضع الداكن
└── .github/workflows/android.yml   ← بناء APK تلقائياً على GitHub Actions
```

لا يوجد مجلد `android/` بعد — ننشئه في الخطوة 3 (مرة واحدة فقط).

---

## 2) التجهيز على جهازك (مرة واحدة)

### المتطلبات
- **Node.js** إصدار 18 أو أحدث (يفضّل 20) — [nodejs.org](https://nodejs.org)
- **Android Studio** (يتضمن Android SDK + JDK) — [developer.android.com/studio](https://developer.android.com/studio)
- حساب GitHub (اختياري، فقط لو تريد البناء عبر GitHub Actions بدل جهازك)

### التثبيت
افتح الطرفية (Terminal) داخل مجلد `agri-mobile/` ونفّذ:

```bash
npm install
```

هذا يثبّت React وTailwind وCapacitor وكل الاعتماديات المذكورة في `package.json`.

### تجربة سريعة في المتصفح (اختياري قبل البناء كـ APK)
```bash
npm run dev
```
يفتح التطبيق على `http://localhost:5173` — جرّب الوضع الداكن، أضف رشاش/بيت محمي، وتأكد أن كل شيء يعمل
كما توقعت قبل الانتقال لأندرويد.

---

## 3) إضافة منصة أندرويد (مرة واحدة فقط)

```bash
npm run build
npx cap add android
```

هذا يُنشئ مجلد `android/` كامل (مشروع Gradle/Android Studio حقيقي) باستخدام إعدادات `capacitor.config.ts`
(اسم الحزمة `com.agri.erp`، اسم التطبيق "أجري ERP"). هذه الخطوة تحتاج إنترنت (لتحميل مكوّنات Gradle)
فقط في أول مرة.

> 💡 **نصيحة**: بعد هذه الخطوة، أضِف مجلد `android/` لنظام git (`git add android`) واحفظه — هذا هو
> المكان الذي تتحكم منه لاحقاً بأيقونة التطبيق، الصلاحيات، واسم الحزمة النهائي عند النشر على Google Play.

كل مرة تغيّر فيها كود React وتريد تحديث النسخة الأندرويد:

```bash
npm run build
npx cap sync android
```

(`npm run cap:sync` يقوم بالاثنين معاً).

---

## 4) بناء APK — عبر Android Studio (الطريقة المباشرة)

1. ```bash
   npx cap open android
   ```
   يفتح Android Studio على مشروعك تلقائياً (أول فتح قد يستغرق دقائق لتحميل Gradle).

2. انتظر حتى ينتهي شريط "Gradle sync" أسفل النافذة.

3. من القائمة العلوية: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

4. عند الانتهاء تظهر إشعار صغير "APK(s) generated successfully" — اضغط **locate** لفتح مكان الملف،
   أو تجده هنا مباشرة:
   ```
   android/app/build/outputs/apk/debug/app-debug.apk
   ```

5. **لتجربته على جوالك**: فعّل "مصادر غير معروفة / Unknown sources" في إعدادات الأندرويد، ثم انسخ
   الـ APK للجوال (عبر كابل أو رفعه على Drive) وافتحه للتثبيت.

### لإصدار APK موقّع (Release) جاهز للنشر على المتجر
داخل Android Studio: **Build → Generate Signed Bundle / APK → APK** → أنشئ Keystore جديد (أول مرة) أو
استخدم الموجود → اتبع الخطوات. الناتج يكون في `android/app/release/`.

---

## 5) بناء APK — عبر GitHub Actions (بدون جهازك، تلقائي)

الملف `.github/workflows/android.yml` جاهز ويقوم بكل الخطوات تلقائياً: تثبيت الاعتماديات، بناء الواجهة،
إنشاء/مزامنة مشروع أندرويد، وبناء APK تجريبي (debug).

### الخطوات
1. أنشئ مستودع (repository) جديد على GitHub وارفع هذا المجلد كاملاً إليه:
   ```bash
   git init
   git add .
   git commit -m "أجري ERP - مشروع Capacitor"
   git branch -M main
   git remote add origin <رابط-مستودعك-على-GitHub>
   git push -u origin main
   ```
2. على GitHub، افتح تبويب **Actions** — ستجد الـ workflow يعمل تلقائياً بعد الرفع (أو فعّله يدوياً من
   زر **Run workflow** إن اخترت `workflow_dispatch`).
3. بعد انتهاء التنفيذ (أيقونة ✅ خضراء)، افتح تفاصيل التشغيل (run) ثم مرّر لأسفل إلى قسم **Artifacts**
   وستجد `agri-erp-debug-apk` — نزّله، وبداخله ملف `app-debug.apk` جاهز للتثبيت على أي جوال أندرويد.

> لا حاجة لتثبيت أي شيء على جهازك بهذه الطريقة — كل البناء يحدث على خوادم GitHub.

---

## 6) الوضع الداكن / الفاتح — كيف يعمل

- زر 🌙/☀️ في الهيدر وفي الإعدادات يبدّل الوضع فوراً ويحفظه في `localStorage` تحت المفتاح `agri-theme`.
- أول مرة يفتح التطبيق (بدون تفضيل محفوظ)، يتبع تلقائياً إعداد نظام الجهاز (داكن/فاتح).
- `src/index.css` يحتوي طبقة تحويل تجعل كلاسات Tailwind الثابتة (`bg-white`, `text-slate-800`...) تتبدّل
  تلقائياً عند وجود كلاس `.dark` على عنصر `<html>` — بدون الحاجة لتعديل كل سطر في `App.jsx`.
- لو أضفت لاحقاً كلاس لون جديد وحسّيت أنه غير واضح في الوضع الداكن، أضف له سطراً مشابهاً في نهاية
  `src/index.css` (الأمثلة الموجودة تكفي كمرجع).

---

## 7) ملاحظات إضافية

- **الأيقونة وشاشة البدء (Splash Screen)**: بعد إنشاء مجلد `android/`، استخدم حزمة
  `@capacitor/assets` (`npm install @capacitor/assets --save-dev` ثم `npx capacitor-assets generate`)
  مع ملفات صور مصدرية (`resources/icon.png`, `resources/splash.png`) لتوليد كل أحجام الأيقونات تلقائياً.
- **اسم الحزمة** (`com.agri.erp`) و**اسم التطبيق** تُغيَّر من `capacitor.config.ts` **قبل** تنفيذ
  `npx cap add android`. لو غيّرتها بعد إنشاء المجلد، يلزم حذف `android/` وإعادة `cap add android`.
- **الخطوط**: التطبيق يحمّل خط Tajawal من Google Fonts عبر الإنترنت في أول تشغيل (ثم يُخزَّن مؤقتاً
  من WebView). لتطبيق يعمل بالكامل دون إنترنت من أول لحظة، نزّل ملفات الخط وضمّنها محلياً في
  `src/index.css` عبر `@font-face` بدل سطر `@import` الحالي.
- **البيانات التجريبية**: أول تشغيل يعرض معالج إعداد بسيط لاختيار الوحدات المفعّلة (رشاشات/بيوت
  محمية/بساتين) — هذا جزء من التطبيق نفسه، لا علاقة له بـ Capacitor.
